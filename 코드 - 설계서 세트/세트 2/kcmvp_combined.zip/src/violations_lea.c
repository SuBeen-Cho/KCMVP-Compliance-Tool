#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "lea.h"

/* ─── 위반 LEA-003: 라운드 수 오류 ──────────────────────────────────────── */

/* [V1] LEA-128: 라운드를 24가 아닌 20으로 잘못 설정 */
void lea003_wrong_rounds_128(LEA_CTX *ctx, const uint8_t *key) {
    lea_set_key(ctx, key, 128);
    ctx->rounds = 20;           /* [위반: LEA-003] 128-bit → 24 라운드여야 함 */
}

/* [V2] LEA-192: 라운드를 28이 아닌 24로 잘못 설정 */
void lea003_wrong_rounds_192(LEA_CTX *ctx, const uint8_t *key) {
    lea_set_key(ctx, key, 192);
    ctx->rounds = 24;           /* [위반: LEA-003] 192-bit → 28 라운드여야 함 */
}

/* ─── 위반 LEA-011: 델타 상수 누락·변조 ────────────────────────────────── */

/* [V3] 표준 델타 상수 8개 중 일부를 임의 값으로 대체 */
static const uint32_t BAD_DELTA[8] = {
    0xc3efe9db,  /* δ[0] 정상 */
    0x44626b02,  /* δ[1] 정상 */
    0x79e27c8a,  /* δ[2] 정상 */
    0x78df30ec,  /* δ[3] 정상 */
    0xDEADBEEF,  /* [위반: LEA-011] δ[4] 변조 (표준: 0x715ea49e) */
    0xCAFEBABE,  /* [위반: LEA-011] δ[5] 변조 (표준: 0xc785da0a) */
    0xFEEDFACE,  /* [위반: LEA-011] δ[6] 변조 (표준: 0xe04ef22a) */
    0x00000000,  /* [위반: LEA-011] δ[7] 변조 (표준: 0xe5c40957) */
};

/* ─── 위반 LEA-016: ROL 비트 수 오류 (T[0] 갱신) ─────────────────────── */

static inline uint32_t ROL32(uint32_t x, int n) {
    return (x << n) | (x >> (32 - n));
}

/* [V4] T[0] 갱신 시 ROL1 대신 ROL2 사용 */
uint32_t lea016_wrong_rol1(uint32_t T0, uint32_t delta) {
    return ROL32(T0 + delta, 2);   /* [위반: LEA-016] ROL1이어야 함 */
}

/* ─── 위반 LEA-017: ROL 비트 수 오류 (T[1] 갱신) ─────────────────────── */

/* [V5] T[1] 갱신 시 ROL3 대신 ROL4 사용 */
uint32_t lea017_wrong_rol3(uint32_t T1, uint32_t delta) {
    return ROL32(T1 + delta, 4);   /* [위반: LEA-017] ROL3이어야 함 */
}

/* ─── 위반 LEA-005: 빅 엔디안 바이트-워드 변환 ──────────────────────── */

/* [V6] 리틀 엔디안 대신 빅 엔디안으로 바이트 배열 → 워드 변환 */
uint32_t lea005_big_endian_load(const uint8_t *b, int i) {
    return ((uint32_t)b[4*i+0] << 24) |   /* [위반: LEA-005] 빅 엔디안 연접 */
           ((uint32_t)b[4*i+1] << 16) |
           ((uint32_t)b[4*i+2] <<  8) |
           ((uint32_t)b[4*i+3]);
    /* 올바른 리틀 엔디안:
       b[4i+3]<<24 | b[4i+2]<<16 | b[4i+1]<<8 | b[4i+0] */
}
