#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "lea.h"

/* ─── 위반 CBC-001: 암호화 연쇄 수식 오류 ───────────────────────────────── */

/* [V1] XOR 대상이 이전 암호문(CT[i-1]) 대신 이전 평문(PT[i-1]) */
int cbc001_xor_prev_pt(const LEA_CTX *ctx, const uint8_t *iv,
                        const uint8_t *pt, size_t len, uint8_t *ct) {
    size_t blocks = len / 16;
    uint8_t tmp[16];
    const uint8_t *prev_pt = iv;   /* 첫 블록은 IV와 XOR */
    for (size_t i = 0; i < blocks; i++) {
        for (int j = 0; j < 16; j++)
            tmp[j] = pt[i*16+j] ^ prev_pt[j];   /* [위반: CBC-001] prev_PT 사용 */
        lea_encrypt_block(ctx, tmp, ct + i*16);
        prev_pt = pt + i*16;        /* CT[i-1] 대신 PT[i] 를 다음 블록에 사용 */
    }
    return 0;
}

/* [V2] 평문을 먼저 암호화한 뒤 XOR (순서 역전) */
int cbc001_enc_then_xor(const LEA_CTX *ctx, const uint8_t *iv,
                         const uint8_t *pt, size_t len, uint8_t *ct) {
    size_t blocks = len / 16;
    const uint8_t *prev = iv;
    for (size_t i = 0; i < blocks; i++) {
        lea_encrypt_block(ctx, pt + i*16, ct + i*16);  /* 먼저 암호화 */
        for (int j = 0; j < 16; j++)
            ct[i*16+j] ^= prev[j];  /* [위반: CBC-001] ENC 후 XOR (역순) */
        prev = ct + i*16;
    }
    return 0;
}

/* ─── 위반 CBC-002: 복호화 연쇄 수식 오류 ───────────────────────────────── */

/* [V3] XOR을 복호화 전에 수행 (올바른 순서: DEC 후 XOR) */
int cbc002_xor_before_dec(const LEA_CTX *ctx, const uint8_t *iv,
                            const uint8_t *ct, size_t len, uint8_t *pt) {
    size_t blocks = len / 16;
    uint8_t tmp[16];
    const uint8_t *prev = iv;
    for (size_t i = 0; i < blocks; i++) {
        for (int j = 0; j < 16; j++)
            tmp[j] = ct[i*16+j] ^ prev[j];    /* [위반: CBC-002] XOR 먼저 */
        lea_decrypt_block(ctx, tmp, pt + i*16); /* 이후 복호화 */
        prev = ct + i*16;
    }
    return 0;
}

/* [V4] 이전 암호문 블록이 아닌 IV를 매 블록에 고정 사용 */
int cbc002_fixed_iv_xor(const LEA_CTX *ctx, const uint8_t *iv,
                          const uint8_t *ct, size_t len, uint8_t *pt) {
    size_t blocks = len / 16;
    uint8_t tmp[16];
    for (size_t i = 0; i < blocks; i++) {
        lea_decrypt_block(ctx, ct + i*16, tmp);
        for (int j = 0; j < 16; j++)
            pt[i*16+j] = tmp[j] ^ iv[j];  /* [위반: CBC-002] 매 블록 IV XOR (CT[i-1] 아님) */
    }
    return 0;
}

/* ─── 위반 CBC-003: IV 랜덤성 미흡 ──────────────────────────────────────── */

/* [V5] srand 없이 rand()로만 IV 생성 (시드 미초기화) */
int cbc003_unseeded_rand(const LEA_CTX *ctx,
                          const uint8_t *pt, size_t len, uint8_t *ct) {
    uint8_t iv[16];
    for (int i = 0; i < 16; i++)
        iv[i] = (uint8_t)(rand() & 0xff);   /* [위반: CBC-003] DRBG 미사용 */
    return lea_cbc_encrypt(ctx, pt, ct, len, iv);
}

/* [V6] 연속 암호화에서 이전 암호문 마지막 블록을 IV로 재사용 */
static uint8_t session_iv[16] = {
    0x10,0x20,0x30,0x40, 0x50,0x60,0x70,0x80,
    0x90,0xa0,0xb0,0xc0, 0xd0,0xe0,0xf0,0x00
};
int cbc003_reused_iv(const LEA_CTX *ctx,
                      const uint8_t *pt, size_t len, uint8_t *ct) {
    int ret = lea_cbc_encrypt(ctx, pt, ct, len, session_iv);
    /* [위반: CBC-003] 다음 호출을 위해 마지막 CT 블록을 IV로 덮어씀 */
    memcpy(session_iv, ct + len - 16, 16);
    return ret;
}

/* ─── 위반 CBC-004: SSP 메모리 제로화 누락 ──────────────────────────────── */

/* [V7] memset 사용(컴파일러 최적화에 의해 제거될 수 있음) */
int cbc004_memset_only(const uint8_t *key, const uint8_t *pt,
                        size_t len, uint8_t *ct) {
    LEA_CTX ctx;
    uint8_t iv[16];
    lea_csprng(iv, 16);
    lea_set_key(&ctx, key, 128);
    lea_cbc_encrypt(&ctx, pt, ct, len, iv);
    memset(iv,  0, sizeof(iv));    /* [위반: CBC-004] memset → memset_s 필요 */
    memset(&ctx, 0, sizeof(ctx)); /* [위반: CBC-004] 컴파일러 최적화 시 삭제 위험 */
    return 0;
}

/* ─── 위반 CBC-005: 패딩 오라클 공격 노출 ──────────────────────────────── */

/* [V8] 특정 PADDING_ERROR 코드 반환 + 위치 정보 노출 */
#define PADDING_ERROR  (-2)
#define MAC_ERROR      (-3)

int cbc005_specific_error(const LEA_CTX *ctx, const uint8_t *iv,
                            const uint8_t *ct, size_t len, uint8_t *pt) {
    size_t blocks = len / 16;
    uint8_t tmp[16];
    const uint8_t *prev = iv;
    for (size_t i = 0; i < blocks; i++) {
        lea_decrypt_block(ctx, ct + i*16, tmp);
        for (int j = 0; j < 16; j++) pt[i*16+j] = tmp[j] ^ prev[j];
        prev = ct + i*16;
    }
    uint8_t pad = pt[len-1];
    if (pad == 0 || pad > 16) {
        /* [위반: CBC-005] 패딩 오류를 별도 코드로 구분 노출 */
        fprintf(stderr, "PADDING_ERROR at byte %zu: 0x%02x\n", len-1, pad);
        return PADDING_ERROR;
    }
    for (uint8_t k = 1; k <= pad; k++) {
        if (pt[len-k] != pad) {
            fprintf(stderr, "PADDING_ERROR mismatch at pos %d\n", (int)(len-k));
            return PADDING_ERROR;  /* [위반: CBC-005] 단순 -1이 아닌 전용 코드 */
        }
    }
    return (int)(len - pad);
}

/* ─── 위반 CBC-061: IV 길이 오류 ─────────────────────────────────────────── */

uint8_t iv_20[20] = {                               /* [위반: CBC-061] 20바이트 */
    0x01,0x02,0x03,0x04, 0x05,0x06,0x07,0x08,
    0x09,0x0a,0x0b,0x0c, 0x0d,0x0e,0x0f,0x10,
    0x11,0x12,0x13,0x14
};
uint8_t iv_4[4] = {0xAA,0xBB,0xCC,0xDD};           /* [위반: CBC-061] 4바이트 */

/* ─── 위반 CBC-LEA-004: 비표준 함수명 사용 ─────────────────────────────── */

/* [V9] encrypt_cbc / decrypt_cbc 비표준 명칭 */
int encrypt_cbc(const LEA_CTX *ctx, const uint8_t *iv,    /* [위반: CBC-LEA-004] */
                const uint8_t *pt, size_t len, uint8_t *ct) {
    return lea_cbc_encrypt(ctx, pt, ct, len, iv);
}

int decrypt_cbc(const LEA_CTX *ctx, const uint8_t *iv,    /* [위반: CBC-LEA-004] */
                const uint8_t *ct, size_t len, uint8_t *pt) {
    return lea_cbc_decrypt(ctx, ct, pt, len, iv);
}

/* ─── 위반 CBC-LEA-005: MCT 키 갱신 수식 오류 ──────────────────────────── */

/* [V10] 키 갱신 시 XOR(^=) 대신 OR(|=) 사용 */
void cbc_mct_or_key_update(const uint8_t *init_key, int key_len,
                             const uint8_t *init_iv,  const uint8_t *init_pt) {
    uint8_t key[32], iv[16], pt[16], ct[16];
    LEA_CTX ctx;
    memcpy(key, init_key, key_len);
    memcpy(iv,  init_iv,  16);
    memcpy(pt,  init_pt,  16);

    for (int i = 0; i < 100; i++) {
        for (int j = 0; j < 1000; j++) {
            uint8_t tmp[16];
            lea_set_key(&ctx, key, key_len * 8);
            for (int k = 0; k < 16; k++) tmp[k] = pt[k] ^ iv[k];
            lea_encrypt_block(&ctx, tmp, ct);
            memcpy(iv, ct, 16);
            memcpy(pt, ct, 16);
        }
        for (int k = 0; k < key_len; k++)
            key[k] |= ct[k % 16];   /* [위반: CBC-LEA-005] |= 대신 ^= 이어야 함 */
    }
    lea_secure_zero(key, sizeof(key));
    lea_secure_zero(&ctx, sizeof(ctx));
}
