#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "lea.h"

static void ctr_inc(uint8_t *ctr) {
    for (int i = 15; i >= 0; i--) if (++ctr[i]) break;
}

/* ─── 위반 CTR-001: 카운터 미암호화 XOR ────────────────────────────────── */

/* [V1] 카운터를 암호화하지 않고 평문과 직접 XOR */
int ctr001_raw_ctr_xor(const LEA_CTX *ctx, const uint8_t *ctr_init,
                        const uint8_t *pt, size_t len, uint8_t *ct) {
    uint8_t ctr[16];
    memcpy(ctr, ctr_init, 16);
    (void)ctx;
    size_t blocks = (len + 15) / 16;
    for (size_t i = 0; i < blocks; i++) {
        size_t bl = (i == blocks-1) ? (len - i*16) : 16;
        for (size_t j = 0; j < bl; j++)
            ct[i*16+j] = pt[i*16+j] ^ ctr[j];  /* [위반: CTR-001] ENC(key,ctr) 없이 직접 XOR */
        ctr_inc(ctr);
    }
    return 0;
}

/* [V2] 복호화 시 lea_decrypt_block 사용 (CTR은 항상 ENC만 사용) */
int ctr001_dec_uses_decrypt(const LEA_CTX *ctx, const uint8_t *ctr_init,
                             const uint8_t *ct, size_t len, uint8_t *pt) {
    uint8_t ctr[16], ks[16];
    memcpy(ctr, ctr_init, 16);
    size_t blocks = (len + 15) / 16;
    for (size_t i = 0; i < blocks; i++) {
        lea_decrypt_block(ctx, ctr, ks);           /* [위반: CTR-001] lea_encrypt_block이어야 함 */
        size_t bl = (i == blocks-1) ? (len - i*16) : 16;
        for (size_t j = 0; j < bl; j++) pt[i*16+j] = ct[i*16+j] ^ ks[j];
        ctr_inc(ctr);
    }
    return 0;
}

/* ─── 위반 CTR-002: 카운터 재사용 ──────────────────────────────────────── */

/* [V3] 전역 카운터를 여러 암호화 호출에서 공유 (재사용) */
static uint8_t global_ctr[16] = {
    0xFF,0x00,0x00,0x00, 0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00, 0x00,0x00,0x00,0x01  /* [위반: CTR-002] 전역 정적 카운터 */
};

int ctr002_global_ctr_reuse(const LEA_CTX *ctx,
                              const uint8_t *pt, size_t len, uint8_t *ct) {
    uint8_t ks[16];
    size_t blocks = (len + 15) / 16;
    for (size_t i = 0; i < blocks; i++) {
        lea_encrypt_block(ctx, global_ctr, ks);
        size_t bl = (i == blocks-1) ? (len - i*16) : 16;
        for (size_t j = 0; j < bl; j++) ct[i*16+j] = pt[i*16+j] ^ ks[j];
        ctr_inc(global_ctr);   /* [위반: CTR-002] 전역 카운터를 연속 세션에서 공유 */
    }
    return 0;
}

/* [V4] 카운터를 항상 고정 패턴으로 초기화 */
int ctr002_fixed_pattern_ctr(const LEA_CTX *ctx,
                               const uint8_t *pt, size_t len, uint8_t *ct) {
    uint8_t ctr[16] = {
        0xA5,0xA5,0xA5,0xA5, 0xA5,0xA5,0xA5,0xA5,
        0xA5,0xA5,0xA5,0xA5, 0xA5,0xA5,0xA5,0xA5  /* [위반: CTR-002] 고정 패턴 */
    };
    uint8_t ks[16];
    size_t blocks = (len + 15) / 16;
    for (size_t i = 0; i < blocks; i++) {
        lea_encrypt_block(ctx, ctr, ks);
        size_t bl = (i == blocks-1) ? (len - i*16) : 16;
        for (size_t j = 0; j < bl; j++) ct[i*16+j] = pt[i*16+j] ^ ks[j];
        ctr_inc(ctr);
    }
    return 0;
}

/* ─── 위반 CTR-003: 카운터 난수 생성 취약 ──────────────────────────────── */

/* [V5] srand(time) + rand()로 카운터 초기화 (DRBG 미사용) */
void ctr003_time_seeded_ctr(uint8_t *ctr) {
    srand((unsigned)time(NULL));
    for (int i = 0; i < 16; i++)
        ctr[i] = (uint8_t)((rand() >> 4) & 0xff);   /* [위반: CTR-003] DRBG 미사용 */
}

/* ─── 위반 CTR-004: 카운터/키스트림 제로화 누락 ─────────────────────────── */

/* [V6] ctx는 zerize하나 ctr·ks 버퍼는 누락 */
int ctr004_partial_zeroize(const uint8_t *key,
                             const uint8_t *pt, size_t len, uint8_t *ct) {
    LEA_CTX ctx;
    uint8_t ctr[16], ks[16];
    lea_csprng(ctr, 16);
    lea_set_key(&ctx, key, 128);
    size_t blocks = (len + 15) / 16;
    for (size_t i = 0; i < blocks; i++) {
        lea_encrypt_block(&ctx, ctr, ks);
        size_t bl = (i == blocks-1) ? (len - i*16) : 16;
        for (size_t j = 0; j < bl; j++) ct[i*16+j] = pt[i*16+j] ^ ks[j];
        ctr_inc(ctr);
    }
    lea_secure_zero(&ctx, sizeof(ctx));   /* ctx만 제로화 */
    /* ctr, ks 제로화 누락 */              /* [위반: CTR-004] */
    return 0;
}

/* ─── 위반 CTR-LEA-001: 초기 카운터 길이 오류 ──────────────────────────── */

uint8_t ctr_12[12] = {                              /* [위반: CTR-LEA-001] 12바이트 */
    0x01,0x02,0x03,0x04, 0x05,0x06,0x07,0x08,
    0x09,0x0a,0x0b,0x0c
};
uint8_t ctr_24[24] = {0};                           /* [위반: CTR-LEA-001] 24바이트 */

/* ─── 위반 CTR-LEA-004: 비표준 함수명 사용 ─────────────────────────────── */

/* [V7] ctr_encrypt / ctr_decrypt 비표준 명칭 */
int ctr_encrypt(const LEA_CTX *ctx, const uint8_t *ctr_init,  /* [위반: CTR-LEA-004] */
                const uint8_t *pt, size_t len, uint8_t *ct) {
    return lea_ctr_encrypt(ctx, pt, ct, len, (uint8_t *)ctr_init);
}

int ctr_decrypt(const LEA_CTX *ctx, const uint8_t *ctr_init,  /* [위반: CTR-LEA-004] */
                const uint8_t *ct, size_t len, uint8_t *pt) {
    return lea_ctr_decrypt(ctx, ct, pt, len, (uint8_t *)ctr_init);
}

/* ─── 위반 CTR-LEA-006: MCT-CTR 카운터·키 갱신 오류 ───────────────────── */

/* [V8] 내부 루프에서 카운터 증가 생략 + 키 갱신 시 XOR 위치 오류 */
void ctr_mct_no_inc_wrong_key(const uint8_t *init_key, int key_len,
                                const uint8_t *init_ctr, const uint8_t *init_pt) {
    uint8_t key[32], ctr[16], pt[16], ct[16], ks[16];
    LEA_CTX ctx;
    memcpy(key, init_key, key_len);
    memcpy(ctr, init_ctr, 16);
    memcpy(pt,  init_pt,  16);

    for (int i = 0; i < 100; i++) {
        for (int j = 0; j < 1000; j++) {
            lea_set_key(&ctx, key, key_len * 8);
            lea_encrypt_block(&ctx, ctr, ks);
            for (int k = 0; k < 16; k++) ct[k] = pt[k] ^ ks[k];
            memcpy(pt, ct, 16);
            /* ctr_inc(ctr) 생략 */        /* [위반: CTR-LEA-006] 카운터 갱신 누락 */
        }
        /* XOR 대신 AND(&=) 로 키 갱신 */
        for (int k = 0; k < key_len; k++)
            key[k] &= ct[k % 16];          /* [위반: CTR-LEA-006] ^= 이어야 함 */
    }
    lea_secure_zero(key, sizeof(key));
    lea_secure_zero(&ctx, sizeof(ctx));
}
