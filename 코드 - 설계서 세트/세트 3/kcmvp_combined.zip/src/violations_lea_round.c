#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "lea.h"

static inline uint32_t ROL32(uint32_t x, int n) {
    return (x << n) | (x >> (32 - n));
}
static inline uint32_t ROR32(uint32_t x, int n) {
    return (x >> n) | (x << (32 - n));
}

/* ─── 위반 LEA-018: 키 스케줄 T[2] ROL6 → ROL4 오류 ─────────────────────── */

/* [V1] T[2] 갱신 시 ROL6 대신 ROL4 사용 */
uint32_t lea018_wrong_rol6(uint32_t T2, uint32_t delta) {
    return ROL32(T2 + delta, 4);   /* [위반: LEA-018] ROL6이어야 함 */
}

/* [V2] 128-bit 키 스케줄에서 T[2] 갱신 위치 전체를 ROL4로 대체 */
void lea018_keysched_wrong_rol6(LEA_CTX *ctx, const uint8_t *key) {
    uint32_t T[4];
    static const uint32_t delta[4] = {
        0xc3efe9db, 0x44626b02, 0x79e27c8a, 0x78df30ec
    };
    /* 바이트→워드 (리틀 엔디안) */
    for (int i = 0; i < 4; i++)
        T[i] = ((uint32_t)key[4*i+3]<<24)|((uint32_t)key[4*i+2]<<16)
              |((uint32_t)key[4*i+1]<< 8)|((uint32_t)key[4*i+0]);

    for (int i = 0; i < 24; i++) {
        T[0] = ROL32(T[0] + delta[i % 4], 1);
        T[1] = ROL32(T[1] + delta[i % 4], 3);
        T[2] = ROL32(T[2] + delta[i % 4], 4);  /* [위반: LEA-018] ROL6이어야 함 */
        T[3] = ROL32(T[3] + delta[i % 4], 11);
        ctx->rk[0][i] = T[0];
        ctx->rk[1][i] = T[1];
        ctx->rk[2][i] = T[2];
        ctx->rk[3][i] = T[1];
        ctx->rk[4][i] = T[3];
        ctx->rk[5][i] = T[1];
    }
}

/* ─── 위반 LEA-019: 키 스케줄 T[3] ROL11 → ROL13 오류 ─────────────────── */

/* [V3] T[3] 갱신 시 ROL11 대신 ROL13 사용 */
uint32_t lea019_wrong_rol11(uint32_t T3, uint32_t delta) {
    return ROL32(T3 + delta, 13);  /* [위반: LEA-019] ROL11이어야 함 */
}

/* [V4] 192-bit 키 스케줄에서 T[3] 갱신 위치를 ROL13으로 대체 */
void lea019_keysched_wrong_rol11(LEA_CTX *ctx, const uint8_t *key) {
    uint32_t T[6];
    static const uint32_t delta[6] = {
        0xc3efe9db, 0x44626b02, 0x79e27c8a,
        0x78df30ec, 0x715ea49e, 0xc785da0a
    };
    for (int i = 0; i < 6; i++)
        T[i] = ((uint32_t)key[4*i+3]<<24)|((uint32_t)key[4*i+2]<<16)
              |((uint32_t)key[4*i+1]<< 8)|((uint32_t)key[4*i+0]);

    for (int i = 0; i < 28; i++) {
        T[0] = ROL32(T[0] + delta[i % 6], 1);
        T[1] = ROL32(T[1] + delta[i % 6], 3);
        T[2] = ROL32(T[2] + delta[i % 6], 6);
        T[3] = ROL32(T[3] + delta[i % 6], 13); /* [위반: LEA-019] ROL11이어야 함 */
        T[4] = ROL32(T[4] + delta[i % 6], 13);
        T[5] = ROL32(T[5] + delta[i % 6], 17);
        ctx->rk[0][i] = T[0];
        ctx->rk[1][i] = T[1];
        ctx->rk[2][i] = T[2];
        ctx->rk[3][i] = T[3];
        ctx->rk[4][i] = T[4];
        ctx->rk[5][i] = T[5];
    }
}

/* ─── 위반 LEA-027: 암호화 라운드 ROL9 → ROL8 오류 ─────────────────────── */

/* [V5] Xi+1[0] 계산 시 ROL9 대신 ROL8 사용 */
void lea027_encrypt_wrong_rol9(const LEA_CTX *ctx, const uint8_t *pt, uint8_t *ct) {
    uint32_t X[4], T;
    X[0] = ((uint32_t)pt[ 3]<<24)|((uint32_t)pt[ 2]<<16)|((uint32_t)pt[ 1]<<8)|pt[ 0];
    X[1] = ((uint32_t)pt[ 7]<<24)|((uint32_t)pt[ 6]<<16)|((uint32_t)pt[ 5]<<8)|pt[ 4];
    X[2] = ((uint32_t)pt[11]<<24)|((uint32_t)pt[10]<<16)|((uint32_t)pt[ 9]<<8)|pt[ 8];
    X[3] = ((uint32_t)pt[15]<<24)|((uint32_t)pt[14]<<16)|((uint32_t)pt[13]<<8)|pt[12];

    for (int i = 0; i < ctx->rounds; i++) {
        T    = ROL32((X[0] ^ ctx->rk[0][i]) + (X[1] ^ ctx->rk[1][i]), 8);  /* [위반: LEA-027] ROL9이어야 함 */
        X[1] = ROR32((X[1] ^ ctx->rk[2][i]) + (X[2] ^ ctx->rk[3][i]), 5);
        X[2] = ROR32((X[2] ^ ctx->rk[4][i]) + (X[3] ^ ctx->rk[5][i]), 3);
        X[3] = X[0];
        X[0] = T;
    }
    ct[ 0]=X[0]&0xFF; ct[ 1]=(X[0]>>8)&0xFF; ct[ 2]=(X[0]>>16)&0xFF; ct[ 3]=(X[0]>>24)&0xFF;
    ct[ 4]=X[1]&0xFF; ct[ 5]=(X[1]>>8)&0xFF; ct[ 6]=(X[1]>>16)&0xFF; ct[ 7]=(X[1]>>24)&0xFF;
    ct[ 8]=X[2]&0xFF; ct[ 9]=(X[2]>>8)&0xFF; ct[10]=(X[2]>>16)&0xFF; ct[11]=(X[2]>>24)&0xFF;
    ct[12]=X[3]&0xFF; ct[13]=(X[3]>>8)&0xFF; ct[14]=(X[3]>>16)&0xFF; ct[15]=(X[3]>>24)&0xFF;
}

/* ─── 위반 LEA-028: 암호화 라운드 ROR5 → ROR6 오류 ─────────────────────── */

/* [V6] Xi+1[1] 계산 시 ROR5 대신 ROR6 사용 */
void lea028_encrypt_wrong_ror5(const LEA_CTX *ctx, const uint8_t *pt, uint8_t *ct) {
    uint32_t X[4], T;
    X[0] = ((uint32_t)pt[ 3]<<24)|((uint32_t)pt[ 2]<<16)|((uint32_t)pt[ 1]<<8)|pt[ 0];
    X[1] = ((uint32_t)pt[ 7]<<24)|((uint32_t)pt[ 6]<<16)|((uint32_t)pt[ 5]<<8)|pt[ 4];
    X[2] = ((uint32_t)pt[11]<<24)|((uint32_t)pt[10]<<16)|((uint32_t)pt[ 9]<<8)|pt[ 8];
    X[3] = ((uint32_t)pt[15]<<24)|((uint32_t)pt[14]<<16)|((uint32_t)pt[13]<<8)|pt[12];

    for (int i = 0; i < ctx->rounds; i++) {
        T    = ROL32((X[0] ^ ctx->rk[0][i]) + (X[1] ^ ctx->rk[1][i]), 9);
        X[1] = ROR32((X[1] ^ ctx->rk[2][i]) + (X[2] ^ ctx->rk[3][i]), 6);  /* [위반: LEA-028] ROR5이어야 함 */
        X[2] = ROR32((X[2] ^ ctx->rk[4][i]) + (X[3] ^ ctx->rk[5][i]), 3);
        X[3] = X[0];
        X[0] = T;
    }
    ct[ 0]=X[0]&0xFF; ct[ 1]=(X[0]>>8)&0xFF; ct[ 2]=(X[0]>>16)&0xFF; ct[ 3]=(X[0]>>24)&0xFF;
    ct[ 4]=X[1]&0xFF; ct[ 5]=(X[1]>>8)&0xFF; ct[ 6]=(X[1]>>16)&0xFF; ct[ 7]=(X[1]>>24)&0xFF;
    ct[ 8]=X[2]&0xFF; ct[ 9]=(X[2]>>8)&0xFF; ct[10]=(X[2]>>16)&0xFF; ct[11]=(X[2]>>24)&0xFF;
    ct[12]=X[3]&0xFF; ct[13]=(X[3]>>8)&0xFF; ct[14]=(X[3]>>16)&0xFF; ct[15]=(X[3]>>24)&0xFF;
}

/* ─── 위반 LEA-029: 암호화 라운드 ROR3 → ROR2 오류 ─────────────────────── */

/* [V7] Xi+1[2] 계산 시 ROR3 대신 ROR2 사용 */
void lea029_encrypt_wrong_ror3(const LEA_CTX *ctx, const uint8_t *pt, uint8_t *ct) {
    uint32_t X[4], T;
    X[0] = ((uint32_t)pt[ 3]<<24)|((uint32_t)pt[ 2]<<16)|((uint32_t)pt[ 1]<<8)|pt[ 0];
    X[1] = ((uint32_t)pt[ 7]<<24)|((uint32_t)pt[ 6]<<16)|((uint32_t)pt[ 5]<<8)|pt[ 4];
    X[2] = ((uint32_t)pt[11]<<24)|((uint32_t)pt[10]<<16)|((uint32_t)pt[ 9]<<8)|pt[ 8];
    X[3] = ((uint32_t)pt[15]<<24)|((uint32_t)pt[14]<<16)|((uint32_t)pt[13]<<8)|pt[12];

    for (int i = 0; i < ctx->rounds; i++) {
        T    = ROL32((X[0] ^ ctx->rk[0][i]) + (X[1] ^ ctx->rk[1][i]), 9);
        X[1] = ROR32((X[1] ^ ctx->rk[2][i]) + (X[2] ^ ctx->rk[3][i]), 5);
        X[2] = ROR32((X[2] ^ ctx->rk[4][i]) + (X[3] ^ ctx->rk[5][i]), 2);  /* [위반: LEA-029] ROR3이어야 함 */
        X[3] = X[0];
        X[0] = T;
    }
    ct[ 0]=X[0]&0xFF; ct[ 1]=(X[0]>>8)&0xFF; ct[ 2]=(X[0]>>16)&0xFF; ct[ 3]=(X[0]>>24)&0xFF;
    ct[ 4]=X[1]&0xFF; ct[ 5]=(X[1]>>8)&0xFF; ct[ 6]=(X[1]>>16)&0xFF; ct[ 7]=(X[1]>>24)&0xFF;
    ct[ 8]=X[2]&0xFF; ct[ 9]=(X[2]>>8)&0xFF; ct[10]=(X[2]>>16)&0xFF; ct[11]=(X[2]>>24)&0xFF;
    ct[12]=X[3]&0xFF; ct[13]=(X[3]>>8)&0xFF; ct[14]=(X[3]>>16)&0xFF; ct[15]=(X[3]>>24)&0xFF;
}

/* ─── 위반 LEA-031: ARX 수식 XOR→ADD 순서 역전 ─────────────────────────── */

/* [V8] (a⊕rk) ⊞ (b⊕rk) 대신 a ⊕ (rk ⊞ (b⊕rk)) 수행 */
void lea031_wrong_arx_order(const LEA_CTX *ctx, const uint8_t *pt, uint8_t *ct) {
    uint32_t X[4], T;
    X[0] = ((uint32_t)pt[ 3]<<24)|((uint32_t)pt[ 2]<<16)|((uint32_t)pt[ 1]<<8)|pt[ 0];
    X[1] = ((uint32_t)pt[ 7]<<24)|((uint32_t)pt[ 6]<<16)|((uint32_t)pt[ 5]<<8)|pt[ 4];
    X[2] = ((uint32_t)pt[11]<<24)|((uint32_t)pt[10]<<16)|((uint32_t)pt[ 9]<<8)|pt[ 8];
    X[3] = ((uint32_t)pt[15]<<24)|((uint32_t)pt[14]<<16)|((uint32_t)pt[13]<<8)|pt[12];

    for (int i = 0; i < ctx->rounds; i++) {
        /* [위반: LEA-031] 올바른 순서: (X[n]^rk[n]) + (X[m]^rk[m])
           위반 구현: X[n] ^ (rk[n] + (X[m]^rk[m]))                  */
        T    = ROL32(X[0] ^ (ctx->rk[0][i] + (X[1] ^ ctx->rk[1][i])), 9);
        X[1] = ROR32(X[1] ^ (ctx->rk[2][i] + (X[2] ^ ctx->rk[3][i])), 5);
        X[2] = ROR32(X[2] ^ (ctx->rk[4][i] + (X[3] ^ ctx->rk[5][i])), 3);
        X[3] = X[0];
        X[0] = T;
    }
    ct[ 0]=X[0]&0xFF; ct[ 1]=(X[0]>>8)&0xFF; ct[ 2]=(X[0]>>16)&0xFF; ct[ 3]=(X[0]>>24)&0xFF;
    ct[ 4]=X[1]&0xFF; ct[ 5]=(X[1]>>8)&0xFF; ct[ 6]=(X[1]>>16)&0xFF; ct[ 7]=(X[1]>>24)&0xFF;
    ct[ 8]=X[2]&0xFF; ct[ 9]=(X[2]>>8)&0xFF; ct[10]=(X[2]>>16)&0xFF; ct[11]=(X[2]>>24)&0xFF;
    ct[12]=X[3]&0xFF; ct[13]=(X[3]>>8)&0xFF; ct[14]=(X[3]>>16)&0xFF; ct[15]=(X[3]>>24)&0xFF;
}

/* ─── 위반 LEA-040: 라운드 루프 오프-바이-원 (i<=rounds) ────────────────── */

/* [V9] LEA-128 암호화 시 i < 24 대신 i <= 24 (25회 수행) */
void lea040_off_by_one(const LEA_CTX *ctx, const uint8_t *pt, uint8_t *ct) {
    uint32_t X[4], T;
    X[0] = ((uint32_t)pt[ 3]<<24)|((uint32_t)pt[ 2]<<16)|((uint32_t)pt[ 1]<<8)|pt[ 0];
    X[1] = ((uint32_t)pt[ 7]<<24)|((uint32_t)pt[ 6]<<16)|((uint32_t)pt[ 5]<<8)|pt[ 4];
    X[2] = ((uint32_t)pt[11]<<24)|((uint32_t)pt[10]<<16)|((uint32_t)pt[ 9]<<8)|pt[ 8];
    X[3] = ((uint32_t)pt[15]<<24)|((uint32_t)pt[14]<<16)|((uint32_t)pt[13]<<8)|pt[12];

    for (int i = 0; i <= ctx->rounds; i++) {  /* [위반: LEA-040] i < ctx->rounds 이어야 함 */
        T    = ROL32((X[0] ^ ctx->rk[0][i]) + (X[1] ^ ctx->rk[1][i]), 9);
        X[1] = ROR32((X[1] ^ ctx->rk[2][i]) + (X[2] ^ ctx->rk[3][i]), 5);
        X[2] = ROR32((X[2] ^ ctx->rk[4][i]) + (X[3] ^ ctx->rk[5][i]), 3);
        X[3] = X[0];
        X[0] = T;
    }
    ct[ 0]=X[0]&0xFF; ct[ 1]=(X[0]>>8)&0xFF; ct[ 2]=(X[0]>>16)&0xFF; ct[ 3]=(X[0]>>24)&0xFF;
    ct[ 4]=X[1]&0xFF; ct[ 5]=(X[1]>>8)&0xFF; ct[ 6]=(X[1]>>16)&0xFF; ct[ 7]=(X[1]>>24)&0xFF;
    ct[ 8]=X[2]&0xFF; ct[ 9]=(X[2]>>8)&0xFF; ct[10]=(X[2]>>16)&0xFF; ct[11]=(X[2]>>24)&0xFF;
    ct[12]=X[3]&0xFF; ct[13]=(X[3]>>8)&0xFF; ct[14]=(X[3]>>16)&0xFF; ct[15]=(X[3]>>24)&0xFF;
}
