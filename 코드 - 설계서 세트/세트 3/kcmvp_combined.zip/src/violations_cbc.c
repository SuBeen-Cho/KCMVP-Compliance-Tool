#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "lea.h"

/* ─── 위반 CBC-001: PCBC 방식 연쇄 오류 (CT[i-1] 대신 PT[i-1] XOR) ──────── */

/* [V1] 이전 암호문(CT[i-1]) 대신 이전 평문(PT[i-1])을 XOR에 사용 */
int cbc001_pcbc_mode(const LEA_CTX *ctx, const uint8_t *iv,
                     const uint8_t *pt, size_t len, uint8_t *ct) {
    size_t blocks = len / 16;
    uint8_t tmp[16];
    const uint8_t *prev = iv;
    for (size_t i = 0; i < blocks; i++) {
        for (int j = 0; j < 16; j++)
            tmp[j] = pt[i*16+j] ^ prev[j];
        lea_encrypt_block(ctx, tmp, ct + i*16);
        prev = pt + i*16;   /* [위반: CBC-001] CT[i] 대신 PT[i]를 다음 prev로 사용 */
    }
    return 0;
}

/* [V2] 연쇄 없이 각 블록을 독립적으로 암호화(IV와 최초 XOR만 수행) */
int cbc001_iv_only_xor(const LEA_CTX *ctx, const uint8_t *iv,
                        const uint8_t *pt, size_t len, uint8_t *ct) {
    size_t blocks = len / 16;
    uint8_t tmp[16];
    for (size_t i = 0; i < blocks; i++) {
        for (int j = 0; j < 16; j++)
            tmp[j] = pt[i*16+j] ^ iv[j];  /* [위반: CBC-001] 매 블록 IV XOR(CT 체인 없음) */
        lea_encrypt_block(ctx, tmp, ct + i*16);
    }
    return 0;
}

/* ─── 위반 CBC-002: 복호화 시 이전 CT 대신 항상 IV 사용 ────────────────── */

/* [V3] 복호화 후 CT[i-1] XOR 대신 IV를 매 블록에 고정 사용 */
int cbc002_always_iv(const LEA_CTX *ctx, const uint8_t *iv,
                     const uint8_t *ct, size_t len, uint8_t *pt) {
    size_t blocks = len / 16;
    uint8_t tmp[16];
    for (size_t i = 0; i < blocks; i++) {
        lea_decrypt_block(ctx, ct + i*16, tmp);
        for (int j = 0; j < 16; j++)
            pt[i*16+j] = tmp[j] ^ iv[j];  /* [위반: CBC-002] CT[i-1] 대신 항상 IV 사용 */
    }
    return 0;
}

/* [V4] 복호화 전에 XOR 수행 (순서 역전: XOR → DEC) */
int cbc002_xor_then_dec(const LEA_CTX *ctx, const uint8_t *iv,
                         const uint8_t *ct, size_t len, uint8_t *pt) {
    size_t blocks = len / 16;
    uint8_t tmp[16];
    const uint8_t *prev = iv;
    for (size_t i = 0; i < blocks; i++) {
        for (int j = 0; j < 16; j++)
            tmp[j] = ct[i*16+j] ^ prev[j];  /* [위반: CBC-002] XOR을 복호화 전에 수행 */
        lea_decrypt_block(ctx, tmp, pt + i*16);
        prev = ct + i*16;
    }
    return 0;
}

/* ─── 위반 CBC-003: IV를 이전 암호문에서 유도 (예측 가능) ──────────────── */

/* [V5] 이전 암호화의 마지막 CT 블록을 다음 세션의 IV로 재사용 */
static uint8_t session_last_ct[16] = {
    0x01,0x23,0x45,0x67, 0x89,0xAB,0xCD,0xEF,
    0xFE,0xDC,0xBA,0x98, 0x76,0x54,0x32,0x10
};
int cbc003_derived_iv(const LEA_CTX *ctx,
                       const uint8_t *pt, size_t len, uint8_t *ct) {
    /* [위반: CBC-003] 이전 암호문에서 유도된 IV는 예측 가능 */
    int ret = lea_cbc_encrypt(ctx, pt, ct, len, session_last_ct);
    memcpy(session_last_ct, ct + len - 16, 16);  /* 다음 호출을 위해 갱신 */
    return ret;
}

/* [V6] 시퀀스 번호 기반 IV (순차적으로 예측 가능) */
static uint32_t iv_sequence = 0;
int cbc003_sequential_iv(const LEA_CTX *ctx,
                          const uint8_t *pt, size_t len, uint8_t *ct) {
    uint8_t iv[16] = {0};
    iv_sequence++;
    /* [위반: CBC-003] 순차 카운터로 IV 생성 → 예측 가능 */
    iv[12] = (uint8_t)(iv_sequence >> 24);
    iv[13] = (uint8_t)(iv_sequence >> 16);
    iv[14] = (uint8_t)(iv_sequence >>  8);
    iv[15] = (uint8_t)(iv_sequence      );
    return lea_cbc_encrypt(ctx, pt, ct, len, iv);
}

/* ─── 위반 CBC-004: ctx만 제로화하고 iv는 누락 ──────────────────────────── */

/* [V7] iv 제로화는 수행하지 않고 ctx만 lea_secure_zero */
int cbc004_no_iv_zeroize(const uint8_t *key, const uint8_t *pt,
                          size_t len, uint8_t *ct) {
    LEA_CTX ctx;
    uint8_t iv[16];
    lea_csprng(iv, 16);
    lea_set_key(&ctx, key, 128);
    lea_cbc_encrypt(&ctx, pt, ct, len, iv);
    lea_secure_zero(&ctx, sizeof(ctx));
    /* iv 제로화 누락 */               /* [위반: CBC-004] */
    return 0;
}

/* ─── 위반 CBC-005: 패딩 오류 vs MAC 오류 타이밍 차이 노출 ─────────────── */

/* [V8] 패딩 오류와 MAC 오류를 서로 다른 코드로 반환 (사이드 채널) */
#define ERR_PADDING  (-2)
#define ERR_MAC      (-3)

int cbc005_timing_leak(const LEA_CTX *ctx, const uint8_t *iv,
                        const uint8_t *ct, size_t len,
                        const uint8_t *expected_mac, uint8_t *pt) {
    size_t blocks = len / 16;
    uint8_t tmp[16];
    const uint8_t *prev = iv;
    for (size_t i = 0; i < blocks; i++) {
        lea_decrypt_block(ctx, ct + i*16, tmp);
        for (int j = 0; j < 16; j++) pt[i*16+j] = tmp[j] ^ prev[j];
        prev = ct + i*16;
    }
    /* [위반: CBC-005] 패딩 오류와 MAC 오류를 구분된 코드로 반환 */
    uint8_t pad = pt[len-1];
    if (pad == 0 || pad > 16) return ERR_PADDING;  /* 패딩 오류 즉시 반환 */
    for (uint8_t k = 1; k <= pad; k++)
        if (pt[len-k] != pad) return ERR_PADDING;
    /* MAC 검증 (정상 패딩 후 수행 → 타이밍 차이 발생) */
    if (lea_safe_cmp(pt, expected_mac, 16) != 0) return ERR_MAC;
    return (int)(len - pad);
}

/* ─── 위반 CBC-061: IV 길이 오류 ─────────────────────────────────────────── */

uint8_t iv_6[6]  = {0x11,0x22,0x33,0x44,0x55,0x66};          /* [위반: CBC-061] 6바이트 */
uint8_t iv_32[32] = {0};                                       /* [위반: CBC-061] 32바이트 */

/* ─── 위반 CBC-LEA-004: 비표준 함수명 사용 ─────────────────────────────── */

/* [V9] run_cbc_enc / run_cbc_dec 비표준 명칭 */
int run_cbc_enc(const LEA_CTX *ctx, const uint8_t *iv,    /* [위반: CBC-LEA-004] */
                const uint8_t *pt, size_t len, uint8_t *ct) {
    return lea_cbc_encrypt(ctx, pt, ct, len, iv);
}

int run_cbc_dec(const LEA_CTX *ctx, const uint8_t *iv,    /* [위반: CBC-LEA-004] */
                const uint8_t *ct, size_t len, uint8_t *pt) {
    return lea_cbc_decrypt(ctx, ct, pt, len, iv);
}

/* ─── 위반 CBC-LEA-005: MCT-CBC IV 갱신 누락 ───────────────────────────── */

/* [V10] 외부 루프 후 IV를 CT[999]로 갱신하지 않고 초기 IV 유지 */
void cbc_mct_no_iv_update(const uint8_t *init_key, int key_len,
                            const uint8_t *init_iv,  const uint8_t *init_pt) {
    uint8_t key[32], iv[16], pt[16], ct[16];
    LEA_CTX ctx;
    memcpy(key, init_key, key_len);
    memcpy(iv,  init_iv,  16);
    memcpy(pt,  init_pt,  16);

    for (int i = 0; i < 100; i++) {
        for (int j = 0; j < 1000; j++) {
            uint8_t tmp[16];
            lea_set_key(&ctx, key, key_len * 8);
            for (int k = 0; k < 16; k++) tmp[k] = pt[k] ^ iv[k];
            lea_encrypt_block(&ctx, tmp, ct);
            /* [위반: CBC-LEA-005] IV 갱신 누락: memcpy(iv, ct, 16) 이어야 함 */
            memcpy(pt, ct, 16);
        }
        for (int k = 0; k < key_len; k++)
            key[k] ^= ct[k % 16];  /* 키 갱신은 정상 XOR이지만 IV 미갱신 */
    }
    lea_secure_zero(key, sizeof(key));
    lea_secure_zero(&ctx, sizeof(ctx));
}
