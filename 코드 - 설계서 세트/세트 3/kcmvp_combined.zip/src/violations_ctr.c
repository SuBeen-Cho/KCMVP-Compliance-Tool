#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "lea.h"

static void ctr_inc(uint8_t *ctr) {
    for (int i = 15; i >= 0; i--) if (++ctr[i]) break;
}

/* ─── 위반 CTR-001: 키스트림 재사용 (카운터 재암호화 없음) ─────────────── */

/* [V1] 첫 블록 키스트림을 생성 후 모든 블록에 반복 적용 */
int ctr001_reused_keystream(const LEA_CTX *ctx, const uint8_t *ctr_init,
                             const uint8_t *pt, size_t len, uint8_t *ct) {
    uint8_t ctr[16], ks[16];
    memcpy(ctr, ctr_init, 16);
    lea_encrypt_block(ctx, ctr, ks);  /* 키스트림 1회만 생성 */
    size_t blocks = (len + 15) / 16;
    for (size_t i = 0; i < blocks; i++) {
        size_t bl = (i == blocks-1) ? (len - i*16) : 16;
        for (size_t j = 0; j < bl; j++)
            ct[i*16+j] = pt[i*16+j] ^ ks[j];  /* [위반: CTR-001] 같은 ks 반복 사용 */
        /* ctr_inc 및 재암호화 없음 */
    }
    return 0;
}

/* [V2] 카운터 블록을 암호화하지 않고 평문 길이만큼 그대로 XOR */
int ctr001_no_enc_xor(const LEA_CTX *ctx, const uint8_t *ctr_init,
                       const uint8_t *pt, size_t len, uint8_t *ct) {
    uint8_t ctr[16];
    memcpy(ctr, ctr_init, 16);
    (void)ctx;
    size_t blocks = (len + 15) / 16;
    for (size_t i = 0; i < blocks; i++) {
        size_t bl = (i == blocks-1) ? (len - i*16) : 16;
        for (size_t j = 0; j < bl; j++)
            ct[i*16+j] = pt[i*16+j] ^ ctr[j % 16];  /* [위반: CTR-001] ENC 없이 카운터 직접 XOR */
        ctr_inc(ctr);
    }
    return 0;
}

/* ─── 위반 CTR-002: 256블록마다 카운터 초기값으로 재설정 ───────────────── */

/* [V3] 256 블록 처리 후 카운터를 초기값으로 다시 리셋 */
int ctr002_wrap_reset(const LEA_CTX *ctx, const uint8_t *ctr_init,
                       const uint8_t *pt, size_t len, uint8_t *ct) {
    uint8_t ctr[16], ks[16];
    memcpy(ctr, ctr_init, 16);
    size_t blocks = (len + 15) / 16;
    for (size_t i = 0; i < blocks; i++) {
        if (i > 0 && (i % 256) == 0)
            memcpy(ctr, ctr_init, 16);  /* [위반: CTR-002] 256블록마다 카운터 재사용 */
        lea_encrypt_block(ctx, ctr, ks);
        size_t bl = (i == blocks-1) ? (len - i*16) : 16;
        for (size_t j = 0; j < bl; j++) ct[i*16+j] = pt[i*16+j] ^ ks[j];
        ctr_inc(ctr);
    }
    return 0;
}

/* [V4] 스레드 공유 전역 카운터 (멀티스레드 환경에서 재사용 가능) */
static uint8_t shared_ctr[16] = {0};
static int     shared_ctr_init = 0;

int ctr002_shared_global_ctr(const LEA_CTX *ctx,
                               const uint8_t *pt, size_t len, uint8_t *ct) {
    if (!shared_ctr_init) {
        /* 최초 1회만 초기화 */
        shared_ctr[15] = 1;
        shared_ctr_init = 1;
    }
    uint8_t ks[16];
    size_t blocks = (len + 15) / 16;
    for (size_t i = 0; i < blocks; i++) {
        lea_encrypt_block(ctx, shared_ctr, ks); /* [위반: CTR-002] 세션 간 전역 카운터 공유 */
        size_t bl = (i == blocks-1) ? (len - i*16) : 16;
        for (size_t j = 0; j < bl; j++) ct[i*16+j] = pt[i*16+j] ^ ks[j];
        ctr_inc(shared_ctr);
    }
    return 0;
}

/* ─── 위반 CTR-003: time(NULL)을 직접 카운터 바이트로 사용 ─────────────── */

/* [V5] time(NULL) 값을 그대로 카운터 첫 8바이트에 복사 */
void ctr003_time_direct(uint8_t *ctr) {
    time_t t = time(NULL);
    memset(ctr, 0, 16);
    memcpy(ctr, &t, sizeof(t));  /* [위반: CTR-003] DRBG 미사용, 시간값 직접 사용 */
}

/* ─── 위반 CTR-004: 키스트림 버퍼(ks) 제로화 누락 ──────────────────────── */

/* [V6] ctx와 ctr은 제로화하지만 ks 버퍼는 누락 */
int ctr004_no_ks_zeroize(const uint8_t *key,
                          const uint8_t *pt, size_t len, uint8_t *ct) {
    LEA_CTX ctx;
    uint8_t ctr[16], ks[16];
    lea_csprng(ctr, 16);
    lea_set_key(&ctx, key, 128);
    size_t blocks = (len + 15) / 16;
    for (size_t i = 0; i < blocks; i++) {
        lea_encrypt_block(&ctx, ctr, ks);
        size_t bl = (i == blocks-1) ? (len - i*16) : 16;
        for (size_t j = 0; j < bl; j++) ct[i*16+j] = pt[i*16+j] ^ ks[j];
        ctr_inc(ctr);
    }
    lea_secure_zero(&ctx, sizeof(ctx));
    lea_secure_zero(ctr, sizeof(ctr));
    /* ks 제로화 누락 */           /* [위반: CTR-004] */
    return 0;
}

/* ─── 위반 CTR-LEA-001: 초기 카운터 길이 오류 ──────────────────────────── */

uint8_t ctr_10[10] = {                              /* [위반: CTR-LEA-001] 10바이트 */
    0xA1,0xB2,0xC3,0xD4, 0xE5,0xF6,0x07,0x18,
    0x29,0x3A
};
uint8_t ctr_20[20] = {0};                           /* [위반: CTR-LEA-001] 20바이트 */

/* ─── 위반 CTR-LEA-004: 비표준 함수명 사용 ─────────────────────────────── */

/* [V7] do_ctr_enc / do_ctr_dec 비표준 명칭 */
int do_ctr_enc(const LEA_CTX *ctx, const uint8_t *ctr_init,  /* [위반: CTR-LEA-004] */
               const uint8_t *pt, size_t len, uint8_t *ct) {
    return lea_ctr_encrypt(ctx, pt, ct, len, (uint8_t *)ctr_init);
}

int do_ctr_dec(const LEA_CTX *ctx, const uint8_t *ctr_init,  /* [위반: CTR-LEA-004] */
               const uint8_t *ct, size_t len, uint8_t *pt) {
    return lea_ctr_decrypt(ctx, ct, pt, len, (uint8_t *)ctr_init);
}

/* ─── 위반 CTR-LEA-006: MCT-CTR 키 갱신 시 뺄셈(-=) 사용 ──────────────── */

/* [V8] 키 갱신 시 XOR(^=) 대신 뺄셈(-=) 사용 */
void ctr_mct_subtract_key(const uint8_t *init_key, int key_len,
                            const uint8_t *init_ctr, const uint8_t *init_pt) {
    uint8_t key[32], ctr[16], pt[16], ct[16], ks[16];
    LEA_CTX ctx;
    memcpy(key, init_key, key_len);
    memcpy(ctr, init_ctr, 16);
    memcpy(pt,  init_pt,  16);

    for (int i = 0; i < 100; i++) {
        for (int j = 0; j < 1000; j++) {
            lea_set_key(&ctx, key, key_len * 8);
            lea_encrypt_block(&ctx, ctr, ks);
            for (int k = 0; k < 16; k++) ct[k] = pt[k] ^ ks[k];
            memcpy(pt, ct, 16);
            ctr_inc(ctr);
        }
        for (int k = 0; k < key_len; k++)
            key[k] -= ct[k % 16];  /* [위반: CTR-LEA-006] ^= 이어야 함 */
    }
    lea_secure_zero(key, sizeof(key));
    lea_secure_zero(&ctx, sizeof(ctx));
}
