#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

/* LEA 기본 컨텍스트 */
typedef struct { uint32_t rk[6][32]; int rounds; } LEA_CTX;

/* LEA 기본 블록 암/복호화 */
int  lea_set_key(LEA_CTX *ctx, const uint8_t *key, int key_bits);
void lea_encrypt_block(const LEA_CTX *ctx, const uint8_t *pt, uint8_t *ct);
void lea_decrypt_block(const LEA_CTX *ctx, const uint8_t *ct, uint8_t *pt);

/* 운용 모드 API */
int  lea_cbc_encrypt(const LEA_CTX *ctx, const uint8_t *pt, uint8_t *ct,
                     size_t len, const uint8_t *iv);
int  lea_cbc_decrypt(const LEA_CTX *ctx, const uint8_t *ct, uint8_t *pt,
                     size_t len, const uint8_t *iv);
int  lea_ctr_encrypt(const LEA_CTX *ctx, const uint8_t *pt, uint8_t *ct,
                     size_t len, uint8_t *counter);
int  lea_ctr_decrypt(const LEA_CTX *ctx, const uint8_t *ct, uint8_t *pt,
                     size_t len, uint8_t *counter);

/* 온라인(스트리밍) API */
typedef struct { LEA_CTX key; uint8_t buf[16]; int initialized; int mode; } LEA_STREAM_CTX;
int  lea_stream_init  (LEA_STREAM_CTX *ctx, const uint8_t *key, int key_bits,
                       const uint8_t *iv, int mode);
int  lea_stream_update(LEA_STREAM_CTX *ctx, const uint8_t *in, uint8_t *out, size_t len);
int  lea_stream_final (LEA_STREAM_CTX *ctx, uint8_t *out, size_t *outlen);

/* 유틸리티 */
void lea_secure_zero(void *buf, size_t len);          /* memset_s 래퍼 */
void lea_csprng     (uint8_t *buf, size_t len);       /* CSPRNG 난수 */
int  lea_safe_cmp   (const void *a, const void *b, size_t len);
