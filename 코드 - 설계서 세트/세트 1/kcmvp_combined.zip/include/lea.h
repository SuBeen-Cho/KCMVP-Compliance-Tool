#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

/* LEA 기본 컨텍스트 */
typedef struct { uint32_t rk[8][32]; } LEA_KEY;

/* LEA 블록 암/복호화 */
int  lea_set_key(LEA_KEY *ctx, const uint8_t *key, int key_bits);
void lea_encrypt_block(const LEA_KEY *ctx, const uint8_t *pt, uint8_t *ct);
void lea_decrypt_block(const LEA_KEY *ctx, const uint8_t *ct, uint8_t *pt);

/* 운용 모드 */
int  lea_cbc_encrypt(const LEA_KEY *ctx, const uint8_t *pt, uint8_t *ct, size_t len, const uint8_t *iv);
int  lea_cbc_decrypt(const LEA_KEY *ctx, const uint8_t *ct, uint8_t *pt, size_t len, const uint8_t *iv);
int  lea_ctr_encrypt(const LEA_KEY *ctx, const uint8_t *pt, uint8_t *ct, size_t len, uint8_t *counter);
int  lea_ctr_decrypt(const LEA_KEY *ctx, const uint8_t *ct, uint8_t *pt, size_t len, uint8_t *counter);

/* 온라인(스트리밍) API */
typedef struct { LEA_KEY key; uint8_t iv[16]; int initialized; } LEA_ONLINE_CTX;
int  lea_online_init  (LEA_ONLINE_CTX *ctx, const uint8_t *key, int key_bits, const uint8_t *iv);
int  lea_online_update(LEA_ONLINE_CTX *ctx, const uint8_t *in, uint8_t *out, size_t len);
int  lea_online_final (LEA_ONLINE_CTX *ctx, uint8_t *out, size_t *outlen);

/* 보안 유틸 */
void lea_zeroize(void *buf, size_t len);          /* = memset_s 래퍼 */
void lea_generate_random(uint8_t *buf, size_t len); /* CSPRNG */
int  crypto_memcmp(const void *a, const void *b, size_t len);
