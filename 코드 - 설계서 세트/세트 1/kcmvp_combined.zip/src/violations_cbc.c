#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "lea.h"

/* ── CBC-001: 암호화 연쇄 수식 위반 ──────────────────────────────────── */

/* [V1] XOR 없이 각 블록 독립 암호화 (ECB와 동일) */
int cbc001_no_xor(const LEA_KEY *ctx, const uint8_t *iv,
                  const uint8_t *pt, size_t len, uint8_t *ct) {
    size_t blocks = len / 16;
    for (size_t i = 0; i < blocks; i++)
        lea_encrypt_block(ctx, pt + i*16, ct + i*16);  /* [위반: CBC-001] IV/이전 CT와 XOR 없음 */
    (void)iv;
    return 0;
}

/* [V2] 암호화 후 XOR (순서 반대: ENC → XOR, 올바른 순서: XOR → ENC) */
int cbc001_xor_after_enc(const LEA_KEY *ctx, const uint8_t *iv,
                          const uint8_t *pt, size_t len, uint8_t *ct) {
    size_t blocks = len / 16;
    const uint8_t *prev = iv;
    for (size_t i = 0; i < blocks; i++) {
        lea_encrypt_block(ctx, pt + i*16, ct + i*16);
        for (int j = 0; j < 16; j++)
            ct[i*16+j] ^= prev[j];   /* [위반: CBC-001] XOR이 암호화 이후에 수행 */
        prev = ct + i*16;
    }
    return 0;
}

/* ── CBC-002: 복호화 연쇄 수식 위반 ──────────────────────────────────── */

/* [V3] 복호화 후 이전 CT와 XOR 없음 */
int cbc002_no_xor(const LEA_KEY *ctx, const uint8_t *iv,
                  const uint8_t *ct, size_t len, uint8_t *pt) {
    size_t blocks = len / 16;
    for (size_t i = 0; i < blocks; i++)
        lea_decrypt_block(ctx, ct + i*16, pt + i*16);  /* [위반: CBC-002] CT[i-1] XOR 없음 */
    (void)iv;
    return 0;
}

/* [V4] XOR 대상을 이전 CT 대신 이전 PT로 사용 */
int cbc002_wrong_xor_target(const LEA_KEY *ctx, const uint8_t *iv,
                             const uint8_t *ct, size_t len, uint8_t *pt) {
    size_t blocks = len / 16;
    uint8_t tmp[16];
    const uint8_t *prev = iv;
    for (size_t i = 0; i < blocks; i++) {
        lea_decrypt_block(ctx, ct + i*16, tmp);
        for (int j = 0; j < 16; j++)
            pt[i*16+j] = tmp[j] ^ (i > 0 ? pt[(i-1)*16+j] : prev[j]); /* [위반: CBC-002] prev_PT 사용 */
        prev = ct + i*16;
    }
    return 0;
}

/* ── CBC-003: IV 랜덤성 미확보 ────────────────────────────────────────── */

/* [V5] rand()로 IV 생성 */
void cbc003_weak_iv(uint8_t *iv) {
    srand((unsigned int)time(NULL));
    for (int i = 0; i < 16; i++)
        iv[i] = (uint8_t)(rand() % 256);   /* [위반: CBC-003] lea_generate_random 필요 */
}

/* [V6] IV를 0으로 고정 */
int cbc003_fixed_iv(const LEA_KEY *ctx, const uint8_t *pt, size_t len, uint8_t *ct) {
    uint8_t iv[16] = {0};               /* [위반: CBC-003] 고정 IV */
    return lea_cbc_encrypt(ctx, pt, ct, len, iv);
}

/* ── CBC-004: IV/Key 메모리 제거 누락 ────────────────────────────────── */

/* [V7] 암호화 후 iv/ctx 제로화 없음 */
int cbc004_no_zeroize(const uint8_t *key, const uint8_t *pt, size_t len, uint8_t *ct) {
    LEA_KEY ctx;
    uint8_t iv[16];
    lea_generate_random(iv, 16);
    lea_set_key(&ctx, key, 128);
    lea_cbc_encrypt(&ctx, pt, ct, len, iv);
    /* iv, ctx 제로화 없음 */           /* [위반: CBC-004] */
    return 0;
}

/* ── CBC-005: 패딩 오라클 공격 방지 위반 ─────────────────────────────── */

/* [V8] 패딩 오류 원인 상세 노출 */
int cbc005_padding_leak(const LEA_KEY *ctx, const uint8_t *iv,
                        const uint8_t *ct, size_t len, uint8_t *pt) {
    size_t blocks = len / 16;
    uint8_t tmp[16];
    const uint8_t *prev = iv;
    for (size_t i = 0; i < blocks; i++) {
        lea_decrypt_block(ctx, ct + i*16, tmp);
        for (int j = 0; j < 16; j++) pt[i*16+j] = tmp[j] ^ prev[j];
        prev = ct + i*16;
    }
    uint8_t pad = pt[len-1];
    if (pad == 0 || pad > 16) {
        /* [위반: CBC-005] 패딩 오류를 외부에 상세 노출 */
        fprintf(stderr, "Padding error: 0x%02x\n", pad);
        return -1;
    }
    return (int)(len - pad);
}

/* ── CBC-061: IV 길이 16바이트 미준수 ────────────────────────────────── */

uint8_t short_iv_8[8]  = {0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08};  /* [위반: CBC-061] */
uint8_t short_iv_12[12] = {0};                                         /* [위반: CBC-061] */

/* ── CBC-LEA-004: 표준 명칭 lea_cbc_enc/dec 미사용 ──────────────────── */

int my_cbc_encrypt(const LEA_KEY *ctx, const uint8_t *iv,  /* [위반: CBC-LEA-004] */
                   const uint8_t *pt, size_t len, uint8_t *ct) {
    return lea_cbc_encrypt(ctx, pt, ct, len, iv);
}

int my_cbc_decrypt(const LEA_KEY *ctx, const uint8_t *iv,  /* [위반: CBC-LEA-004] */
                   const uint8_t *ct, size_t len, uint8_t *pt) {
    return lea_cbc_decrypt(ctx, ct, pt, len, iv);
}

/* ── CBC-LEA-005: MCT-CBC 키 갱신 수식 위반 ─────────────────────────── */

/* [V9] 키 갱신 시 XOR(^=) 대신 덧셈(+=) 사용 */
void cbc_mct_wrong_key_update(const uint8_t *init_key, int key_len,
                               const uint8_t *init_iv, const uint8_t *init_pt) {
    uint8_t key[32], iv[16], pt[16], ct[16];
    LEA_KEY ctx;
    memcpy(key, init_key, key_len);
    memcpy(iv,  init_iv,  16);
    memcpy(pt,  init_pt,  16);

    for (int i = 0; i < 100; i++) {
        for (int j = 0; j < 1000; j++) {
            uint8_t tmp[16];
            lea_set_key(&ctx, key, key_len * 8);
            for (int k = 0; k < 16; k++) tmp[k] = pt[k] ^ iv[k];
            lea_encrypt_block(&ctx, tmp, ct);
            memcpy(iv, ct, 16);
            memcpy(pt, ct, 16);
        }
        for (int k = 0; k < key_len; k++)
            key[k] += ct[k % 16];   /* [위반: CBC-LEA-005] ^= 이어야 함 */
    }
    lea_zeroize(key, sizeof(key));
    lea_zeroize(&ctx, sizeof(ctx));
}
