#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "lea.h"

/* ── COM-001: 잔존 정보 제거 누락 ─────────────────────────────────────── */

/* [V1] 일반 memset 사용 — 컴파일러 최적화로 제거될 수 있음 */
void com001_weak_zeroize(const uint8_t *pt, size_t len, uint8_t *ct) {
    LEA_KEY ctx;
    uint8_t key[16] = {
        0x0f,0x1e,0x2d,0x3c, 0x4b,0x5a,0x69,0x78,
        0x87,0x96,0xa5,0xb4, 0xc3,0xd2,0xe1,0xf0
    };
    lea_set_key(&ctx, key, 128);
    lea_encrypt_block(&ctx, pt, ct);
    memset(key, 0, sizeof(key));    /* [위반: COM-001] memset_s/explicit_bzero 필요 */
    memset(&ctx, 0, sizeof(ctx));   /* [위반: COM-001] */
}

/* [V2] 라운드키 제로화 완전 누락 */
void com001_no_zeroize(const uint8_t *key, const uint8_t *pt, uint8_t *ct) {
    LEA_KEY ctx;
    lea_set_key(&ctx, key, 128);
    lea_encrypt_block(&ctx, pt, ct);
    /* ctx 제로화 없음 */           /* [위반: COM-001] */
}

/* ── COM-002: 에러 처리 누락 ──────────────────────────────────────────── */

/* [V3] lea_set_key 반환값 미확인 */
void com002_no_error_check(const uint8_t *key, const uint8_t *pt, uint8_t *ct) {
    LEA_KEY ctx;
    lea_set_key(&ctx, key, 128);    /* [위반: COM-002] 반환값 무시 */
    lea_encrypt_block(&ctx, pt, ct);
    lea_zeroize(&ctx, sizeof(ctx));
}

/* [V4] 암호화 후 결과 검증 없이 사용 */
int com002_no_result_check(const uint8_t *key, const uint8_t *pt,
                            uint8_t *ct, size_t len, const uint8_t *iv) {
    LEA_KEY ctx;
    lea_set_key(&ctx, key, 128);
    lea_cbc_encrypt(&ctx, pt, ct, len, iv); /* [위반: COM-002] 반환값 무시 */
    lea_zeroize(&ctx, sizeof(ctx));
    return 0;
}

/* ── COM-003: 하드코딩된 키/IV ────────────────────────────────────────── */

/* [V5] 128비트 운용 키가 소스코드에 고정 */
static const uint8_t HARDCODED_KEY_128[16] = {
    0x0f,0x1e,0x2d,0x3c, 0x4b,0x5a,0x69,0x78,   /* [위반: COM-003] */
    0x87,0x96,0xa5,0xb4, 0xc3,0xd2,0xe1,0xf0
};

/* [V6] 256비트 키 하드코딩 */
static const uint8_t HARDCODED_KEY_256[32] = {
    0xaa,0xbb,0xcc,0xdd, 0xee,0xff,0x00,0x11,   /* [위반: COM-003] */
    0x22,0x33,0x44,0x55, 0x66,0x77,0x88,0x99,
    0xaa,0xbb,0xcc,0xdd, 0xee,0xff,0x00,0x11,
    0x22,0x33,0x44,0x55, 0x66,0x77,0x88,0x99
};

/* [V7] IV 하드코딩 */
static const uint8_t HARDCODED_IV[16] = {
    0x00,0x11,0x22,0x33, 0x44,0x55,0x66,0x77,   /* [위반: COM-003] */
    0x88,0x99,0xaa,0xbb, 0xcc,0xdd,0xee,0xff
};

void com003_use_hardcoded_key(const uint8_t *pt, uint8_t *ct) {
    LEA_KEY ctx;
    lea_set_key(&ctx, HARDCODED_KEY_128, 128);   /* [위반: COM-003] */
    lea_encrypt_block(&ctx, pt, ct);
    lea_zeroize(&ctx, sizeof(ctx));
}

void com003_local_hardcoded_key(const uint8_t *pt, uint8_t *ct, size_t len) {
    LEA_KEY ctx;
    uint8_t local_key[16] = {
        0x12,0x34,0x56,0x78, 0x9a,0xbc,0xde,0xf0,   /* [위반: COM-003] */
        0x0f,0xed,0xcb,0xa9, 0x87,0x65,0x43,0x21
    };
    lea_set_key(&ctx, local_key, 128);
    lea_cbc_encrypt(&ctx, pt, ct, len, HARDCODED_IV);  /* [위반: COM-003] */
    lea_zeroize(local_key, sizeof(local_key));
    lea_zeroize(&ctx, sizeof(ctx));
}

/* ── COM-004: 비암호학적 RNG 사용 ─────────────────────────────────────── */

/* [V8] rand()로 IV 생성 — 암호학적 안전성 없음 */
void com004_weak_rng_iv(uint8_t *iv) {
    srand((unsigned int)time(NULL));
    for (int i = 0; i < 16; i++)
        iv[i] = (uint8_t)(rand() & 0xff);   /* [위반: COM-004] lea_generate_random 사용해야 함 */
}

/* [V9] rand()로 키 생성 */
void com004_weak_rng_key(uint8_t *key, int len) {
    for (int i = 0; i < len; i++)
        key[i] = (uint8_t)(rand() % 256);   /* [위반: COM-004] */
}

/* ── COM-005: API 호출 순서 위반 ──────────────────────────────────────── */

/* [V10] init 없이 update 직접 호출 */
void com005_skip_init(LEA_ONLINE_CTX *ctx, uint8_t *data, size_t len, uint8_t *out) {
    lea_online_update(ctx, data, out, len);  /* [위반: COM-005] lea_online_init 먼저 필요 */
    size_t outlen = len;
    lea_online_final(ctx, out, &outlen);
}

/* [V11] final 후 update 재호출 */
void com005_use_after_final(LEA_ONLINE_CTX *ctx,
                             const uint8_t *key, const uint8_t *iv,
                             uint8_t *data, size_t len, uint8_t *out) {
    lea_online_init(ctx, key, 128, iv);
    size_t outlen = len;
    lea_online_final(ctx, out, &outlen);
    lea_online_update(ctx, data, out, len);  /* [위반: COM-005] final 이후 update 금지 */
}

/* ── COM-006: 비표준 API 명칭 ─────────────────────────────────────────── */

/* [V12] 표준 명칭 대신 임의 함수명 사용 */
void my_lea_encrypt(const uint8_t *key, const uint8_t *pt, uint8_t *ct) {  /* [위반: COM-006] */
    LEA_KEY ctx;
    lea_set_key(&ctx, key, 128);
    lea_encrypt_block(&ctx, pt, ct);
    lea_zeroize(&ctx, sizeof(ctx));
}

int do_cbc_enc(const uint8_t *key, const uint8_t *iv,  /* [위반: COM-006] */
               const uint8_t *pt, size_t len, uint8_t *ct) {
    LEA_KEY ctx;
    if (lea_set_key(&ctx, key, 128) != 0) return -1;
    int ret = lea_cbc_encrypt(&ctx, pt, ct, len, iv);
    lea_zeroize(&ctx, sizeof(ctx));
    return ret;
}
