#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "lea.h"

static void ctr_inc(uint8_t *ctr) {
    for (int i = 15; i >= 0; i--) if (++ctr[i]) break;
}

/* ── CTR-001: 암·복호화 수식 위반 ────────────────────────────────────── */

/* [V1] 복호화 시 ENC 대신 DEC 사용 (CTR은 항상 ENC만 사용해야 함) */
int ctr001_decrypt_uses_dec(const LEA_KEY *ctx, const uint8_t *ctr_init,
                             const uint8_t *ct, size_t len, uint8_t *pt) {
    uint8_t ctr[16], ks[16];
    memcpy(ctr, ctr_init, 16);
    size_t blocks = (len + 15) / 16;
    for (size_t i = 0; i < blocks; i++) {
        lea_decrypt_block(ctx, ctr, ks);   /* [위반: CTR-001] lea_encrypt_block이어야 함 */
        size_t bl = (i == blocks-1) ? (len - i*16) : 16;
        for (size_t j = 0; j < bl; j++) pt[i*16+j] = ct[i*16+j] ^ ks[j];
        ctr_inc(ctr);
    }
    return 0;
}

/* [V2] ENC 없이 카운터 값을 그대로 XOR */
int ctr001_no_keystream(const LEA_KEY *ctx, const uint8_t *ctr_init,
                         const uint8_t *pt, size_t len, uint8_t *ct) {
    uint8_t ctr[16];
    memcpy(ctr, ctr_init, 16);
    (void)ctx;
    size_t blocks = (len + 15) / 16;
    for (size_t i = 0; i < blocks; i++) {
        size_t bl = (i == blocks-1) ? (len - i*16) : 16;
        for (size_t j = 0; j < bl; j++)
            ct[i*16+j] = pt[i*16+j] ^ ctr[j];  /* [위반: CTR-001] ENC(Key,CTR) 없이 XOR */
        ctr_inc(ctr);
    }
    return 0;
}

/* ── CTR-002: 카운터 초기값 유일성 미보장 ────────────────────────────── */

/* [V3] static 고정 카운터 재사용 */
static uint8_t reused_counter[16] = {
    0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,1   /* [위반: CTR-002] 매 호출마다 동일 카운터 */
};

int ctr002_reused_nonce(const LEA_KEY *ctx, const uint8_t *pt, size_t len, uint8_t *ct) {
    uint8_t ctr[16], ks[16];
    memcpy(ctr, reused_counter, 16);    /* [위반: CTR-002] 갱신 없이 재사용 */
    size_t blocks = (len + 15) / 16;
    for (size_t i = 0; i < blocks; i++) {
        lea_encrypt_block(ctx, ctr, ks);
        size_t bl = (i == blocks-1) ? (len - i*16) : 16;
        for (size_t j = 0; j < bl; j++) ct[i*16+j] = pt[i*16+j] ^ ks[j];
        ctr_inc(ctr);
    }
    return 0;
}

/* [V4] 카운터를 항상 0으로 초기화 */
int ctr002_zero_counter(const LEA_KEY *ctx, const uint8_t *pt, size_t len, uint8_t *ct) {
    uint8_t ctr[16] = {0};             /* [위반: CTR-002] 항상 0으로 고정 */
    uint8_t ks[16];
    size_t blocks = (len + 15) / 16;
    for (size_t i = 0; i < blocks; i++) {
        lea_encrypt_block(ctx, ctr, ks);
        size_t bl = (i == blocks-1) ? (len - i*16) : 16;
        for (size_t j = 0; j < bl; j++) ct[i*16+j] = pt[i*16+j] ^ ks[j];
        ctr_inc(ctr);
    }
    return 0;
}

/* ── CTR-003: Nonce 랜덤성 미확보 ────────────────────────────────────── */

/* [V5] rand()로 초기 카운터 생성 */
void ctr003_weak_nonce(uint8_t *ctr) {
    srand((unsigned int)time(NULL));
    for (int i = 0; i < 16; i++)
        ctr[i] = (uint8_t)(rand() % 256);  /* [위반: CTR-003] lea_generate_random 필요 */
}

/* ── CTR-004: 카운터/키 메모리 제거 누락 ─────────────────────────────── */

/* [V6] 암호화 후 ctr/ctx 제로화 없음 */
int ctr004_no_zeroize(const uint8_t *key, const uint8_t *pt, size_t len, uint8_t *ct) {
    LEA_KEY ctx;
    uint8_t ctr[16], ks[16];
    lea_generate_random(ctr, 16);
    lea_set_key(&ctx, key, 128);
    size_t blocks = (len + 15) / 16;
    for (size_t i = 0; i < blocks; i++) {
        lea_encrypt_block(&ctx, ctr, ks);
        size_t bl = (i == blocks-1) ? (len - i*16) : 16;
        for (size_t j = 0; j < bl; j++) ct[i*16+j] = pt[i*16+j] ^ ks[j];
        ctr_inc(ctr);
    }
    /* ctr, ks, ctx 제로화 없음 */    /* [위반: CTR-004] */
    return 0;
}

/* ── CTR-LEA-001: 초기 카운터 길이 16바이트 미준수 ──────────────────── */

uint8_t short_ctr_8[8]  = {0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08};  /* [위반: CTR-LEA-001] */
uint8_t short_ctr_12[12] = {0};                                          /* [위반: CTR-LEA-001] */

/* ── CTR-LEA-004: 표준 API lea_ctr_enc/dec 미사용 ───────────────────── */

int my_ctr_encrypt(const LEA_KEY *ctx, const uint8_t *ctr_init,  /* [위반: CTR-LEA-004] */
                   const uint8_t *pt, size_t len, uint8_t *ct) {
    return lea_ctr_encrypt(ctx, pt, ct, len, (uint8_t *)ctr_init);
}

int my_ctr_decrypt(const LEA_KEY *ctx, const uint8_t *ctr_init,  /* [위반: CTR-LEA-004] */
                   const uint8_t *ct, size_t len, uint8_t *pt) {
    return lea_ctr_decrypt(ctx, ct, pt, len, (uint8_t *)ctr_init);
}

/* ── CTR-LEA-006: MCT-CTR 카운터/키 갱신 수식 위반 ─────────────────── */

/* [V7] 카운터 증가 없음 + 키 갱신 시 += 사용 */
void ctr_mct_wrong(const uint8_t *init_key, int key_len,
                   const uint8_t *init_ctr, const uint8_t *init_pt) {
    uint8_t key[32], ctr[16], pt[16], ct[16], ks[16];
    LEA_KEY ctx;
    memcpy(key, init_key, key_len);
    memcpy(ctr, init_ctr, 16);
    memcpy(pt,  init_pt,  16);

    for (int i = 0; i < 100; i++) {
        for (int j = 0; j < 1000; j++) {
            lea_set_key(&ctx, key, key_len * 8);
            lea_encrypt_block(&ctx, ctr, ks);
            for (int k = 0; k < 16; k++) ct[k] = pt[k] ^ ks[k];
            memcpy(pt, ct, 16);
            /* 카운터 증가 없음 */    /* [위반: CTR-LEA-006] ctr_inc(ctr) 필요 */
        }
        for (int k = 0; k < key_len; k++)
            key[k] += ct[k % 16];   /* [위반: CTR-LEA-006] ^= 이어야 함 */
    }
    lea_zeroize(key, sizeof(key));
    lea_zeroize(&ctx, sizeof(ctx));
}
