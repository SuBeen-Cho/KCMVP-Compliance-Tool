/*
 * lea.h  —  LEA-Crypt v2.1.0  공개 인터페이스
 * Copyright (c) 2026 (주)코드시큐어. All rights reserved.
 *
 * 본 파일은 경량 블록암호 LEA(TTAK.KO-12.0223) 기반의 암호모듈
 * 'LEA-Crypt v2.1.0' 의 공개 API 헤더입니다.
 * KCMVP 검증 대상 알고리즘: LEA-128/192/256, CBC, CTR
 */
#pragma once
#include <stdint.h>
#include <stddef.h>

/* ── 오류 코드 ─────────────────────────────────────────────────── */
#define LEA_OK              0
#define LEA_ERR_PARAM      (-1)
#define LEA_ERR_KEYLEN     (-2)
#define LEA_ERR_IVLEN      (-3)
#define LEA_ERR_CTXNULL    (-4)
#define LEA_ERR_SELFTEST   (-5)

/* ── 컨텍스트 구조체 ────────────────────────────────────────────── */
/**
 * LEA 라운드키 컨텍스트.
 * rk[w][r]: 라운드 r 의 서브키 워드 w (w=0..5, r=0..rounds-1)
 * rounds  : 24(LEA-128) / 28(LEA-192) / 32(LEA-256)
 */
typedef struct {
    uint32_t rk[6][32];
    int      rounds;
} LEA_CTX;

/* ── 블록 암/복호화 ────────────────────────────────────────────── */
int  lea_set_key       (LEA_CTX *ctx, const uint8_t *key, int bits);
void lea_encrypt_block (const LEA_CTX *ctx, const uint8_t *pt, uint8_t *ct);
void lea_decrypt_block (const LEA_CTX *ctx, const uint8_t *ct, uint8_t *pt);

/* ── 운용 모드 ─────────────────────────────────────────────────── */
int  lea_cbc_encrypt (const LEA_CTX *ctx, const uint8_t *pt, uint8_t *ct,
                      size_t len, const uint8_t *iv);
int  lea_cbc_decrypt (const LEA_CTX *ctx, const uint8_t *ct, uint8_t *pt,
                      size_t len, const uint8_t *iv);
int  lea_ctr_encrypt (const LEA_CTX *ctx, const uint8_t *pt, uint8_t *ct,
                      size_t len, uint8_t *ctr);
int  lea_ctr_decrypt (const LEA_CTX *ctx, const uint8_t *ct, uint8_t *pt,
                      size_t len, uint8_t *ctr);

/* ── 스트리밍 API ──────────────────────────────────────────────── */
typedef struct {
    LEA_CTX key;
    uint8_t buf[16];
    size_t  buf_len;
    uint8_t state[16];   /* CBC: 이전 CT 블록 / CTR: 현재 카운터 */
    int     initialized;
    int     mode;        /* 0=CBC, 1=CTR */
} LEA_STREAM_CTX;

int lea_stream_init   (LEA_STREAM_CTX *ctx, const uint8_t *key, int bits,
                       const uint8_t *iv, int mode);
int lea_stream_update (LEA_STREAM_CTX *ctx, const uint8_t *in,
                       uint8_t *out, size_t len);
int lea_stream_final  (LEA_STREAM_CTX *ctx, uint8_t *out, size_t *outlen);

/* ── 유틸리티 ─────────────────────────────────────────────────── */
void lea_secure_zero (void *buf, size_t len);   /* memset_s 래퍼 */
void lea_csprng      (uint8_t *buf, size_t len);/* KCMVP 검증 DRBG */
int  lea_safe_cmp    (const void *a, const void *b, size_t len);
