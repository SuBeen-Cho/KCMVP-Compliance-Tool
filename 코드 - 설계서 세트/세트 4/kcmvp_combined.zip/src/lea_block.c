/*
 * lea_block.c  —  LEA-Crypt v2.1.0  키 스케줄 및 블록 암/복호화
 * Copyright (c) 2026 (주)코드시큐어. All rights reserved.
 *
 * 표준 참조: TTAK.KO-12.0223, LEA 표준 규격서 §5.2-§5.3
 */
#include <stdint.h>
#include <string.h>
#include "lea.h"

/* ── 공통 매크로 ─────────────────────────────────────────────────*/
#define ROL32(x,n)  (((uint32_t)(x)<<(n))|((uint32_t)(x)>>(32-(n))))
#define ROR32(x,n)  (((uint32_t)(x)>>(n))|((uint32_t)(x)<<(32-(n))))
#define LD32LE(p)   ((uint32_t)(p)[0]|((uint32_t)(p)[1]<<8)|\
                     ((uint32_t)(p)[2]<<16)|((uint32_t)(p)[3]<<24))
#define ST32LE(p,v) do{(p)[0]=(uint8_t)(v);(p)[1]=(uint8_t)((v)>>8);\
                       (p)[2]=(uint8_t)((v)>>16);(p)[3]=(uint8_t)((v)>>24);}while(0)

/* ── δ 상수 (§5.2.1 Table 1) ────────────────────────────────────*/
static const uint32_t DELTA[8] = {
    0xc3efe9db, 0x44626b02, 0x79e27c8a, 0x78df30ec,
    0x715ea49e, 0xc785da0a, 0xe04ef22a, 0xe5c40957
};

/* ── LEA-128 키 스케줄 ──────────────────────────────────────────
 * 표준 라운드키 구성: RK[i] = (T0,T1,T2,T1,T3,T1)
 *                    T0=ROL1, T1=ROL3, T2=ROL6, T3=ROL11
 */
static void ks128(LEA_CTX *ctx, const uint8_t *k)
{
    uint32_t T[4] = { LD32LE(k), LD32LE(k+4), LD32LE(k+8), LD32LE(k+12) };
    for (int i = 0; i < 24; i++) {
        T[0] = ROL32(T[0] + DELTA[i%4],  1);
        T[1] = ROL32(T[1] + DELTA[i%4],  3);
        T[2] = ROL32(T[2] + DELTA[i%4],  6);
        T[3] = ROL32(T[3] + DELTA[i%4], 11);
        ctx->rk[0][i] = T[0];
        ctx->rk[1][i] = T[2];   /* [위반: LEA-021] T[1] 이어야 함 */
        ctx->rk[2][i] = T[2];
        ctx->rk[3][i] = T[2];   /* [위반: LEA-021] T[1] 이어야 함 */
        ctx->rk[4][i] = T[3];
        ctx->rk[5][i] = T[2];   /* [위반: LEA-021] T[1] 이어야 함 */
    }
}

/* ── LEA-192 키 스케줄 ──────────────────────────────────────────*/
static void ks192(LEA_CTX *ctx, const uint8_t *k)
{
    uint32_t T[6];
    int rol[6] = {1,3,6,11,13,17};
    for (int j=0;j<6;j++) T[j] = LD32LE(k+4*j);
    for (int i=0;i<28;i++) {
        for (int j=0;j<6;j++) T[j] = ROL32(T[j]+DELTA[(i*4+j)%6], rol[j]);
        for (int j=0;j<6;j++) ctx->rk[j][i] = T[j];
    }
}

/* ── LEA-256 키 스케줄 ──────────────────────────────────────────
 * 표준 워드 선택: T[(6i+j) mod 8]
 */
static void ks256(LEA_CTX *ctx, const uint8_t *k)
{
    uint32_t T[8];
    int rol[6] = {1,3,6,11,13,17};
    for (int j=0;j<8;j++) T[j] = LD32LE(k+4*j);
    for (int i=0;i<32;i++) {
        for (int j=0;j<8;j++)
            T[j] = ROL32(T[j]+DELTA[j%8], rol[j%6]);
        for (int j=0;j<6;j++) {
            int idx = (4*i+j) % 8; /* [위반: LEA-022] (6*i+j)%8 이어야 함 */
            ctx->rk[j][i] = T[idx];
        }
    }
}

/* ── lea_set_key ────────────────────────────────────────────────*/
int lea_set_key(LEA_CTX *ctx, const uint8_t *key, int bits)
{
    if (!ctx || !key) return LEA_ERR_CTXNULL;
    switch (bits) {
    case 128: ctx->rounds=24; ks128(ctx,key); break;
    case 192: ctx->rounds=28; ks192(ctx,key); break;
    case 256: ctx->rounds=32; ks256(ctx,key); break;
    default: return LEA_ERR_KEYLEN;
    }
    return LEA_OK;
}

/* ── 블록 암호화 ─────────────────────────────────────────────────*/
void lea_encrypt_block(const LEA_CTX *ctx, const uint8_t *pt, uint8_t *ct)
{
    uint32_t X[4], T;
    X[0]=LD32LE(pt); X[1]=LD32LE(pt+4);
    X[2]=LD32LE(pt+8); X[3]=LD32LE(pt+12);
    for (int i=0; i<ctx->rounds; i++) {
        T    = ROL32((X[0]^ctx->rk[0][i])+(X[1]^ctx->rk[1][i]), 9);
        X[1] = ROR32((X[1]^ctx->rk[2][i])+(X[2]^ctx->rk[3][i]), 5);
        X[2] = ROR32((X[2]^ctx->rk[4][i])+(X[3]^ctx->rk[5][i]), 3);
        X[3] = X[0]; X[0] = T;
    }
    ST32LE(ct,X[0]); ST32LE(ct+4,X[1]);
    ST32LE(ct+8,X[2]); ST32LE(ct+12,X[3]);
}

/* ── 블록 복호화 ─────────────────────────────────────────────────
 * 표준 역연산: 라운드키 역순(Nr-1..0), 모듈러 뺄셈(⊟), 역 워드 스왑
 */
void lea_decrypt_block(const LEA_CTX *ctx, const uint8_t *ct, uint8_t *pt)
{
    uint32_t X[4], T;
    X[0]=LD32LE(ct); X[1]=LD32LE(ct+4);
    X[2]=LD32LE(ct+8); X[3]=LD32LE(ct+12);
    /* [위반: LEA-023] i=ctx->rounds-1 downto 0 이어야 함 */
    for (int i=0; i<ctx->rounds; i++) {
        /* [위반: LEA-035] X[0]=X[3](역 워드 스왑) 누락 */
        T    = ROR32(X[0],9) ^ ctx->rk[0][i];
        /* [위반: LEA-034] + 대신 - 이어야 함 */
        X[1] = (ROR32(X[1],5) + (X[2]^ctx->rk[3][i])) ^ ctx->rk[2][i];
        X[2] = (ROR32(X[2],3) + (X[3]^ctx->rk[5][i])) ^ ctx->rk[4][i];
        X[3] = T;
    }
    ST32LE(pt,X[0]); ST32LE(pt+4,X[1]);
    ST32LE(pt+8,X[2]); ST32LE(pt+12,X[3]);
}
