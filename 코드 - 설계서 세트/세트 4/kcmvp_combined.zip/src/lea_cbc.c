/*
 * lea_cbc.c  —  LEA-Crypt v2.1.0  CBC 운용 모드
 * Copyright (c) 2026 (주)코드시큐어. All rights reserved.
 *
 * CBC 암호화: C[i] = ENC(K, P[i] XOR C[i-1]),  C[-1]=IV
 * CBC 복호화: P[i] = DEC(K, C[i]) XOR C[i-1],  C[-1]=IV
 */
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "lea.h"

/* ── 내부 헬퍼 ──────────────────────────────────────────────────*/
static void xor16(uint8_t *dst, const uint8_t *a, const uint8_t *b) {
    for (int i=0;i<16;i++) dst[i]=a[i]^b[i];
}

/* PKCS#7 패딩 추가 (블록 단위) */
static size_t pkcs7_pad(uint8_t *buf, size_t len, size_t blk) {
    uint8_t pad = (uint8_t)(blk - len%blk);
    for (size_t i=0;i<pad;i++) buf[len+i]=pad;
    return len+pad;
}

/* PKCS#7 패딩 검증 및 제거.  반환: 평문 길이, 오류 시 음수 */
static int pkcs7_verify(const uint8_t *buf, size_t len) {
    if (len==0||len%16!=0) return LEA_ERR_PARAM;
    uint8_t pad = buf[len-1];
    if (pad==0||pad>16) {
        fprintf(stderr, "[LEA-Crypt] padding error: byte=0x%02x pos=%zu\n",
                pad, len-1);             /* [위반: CBC-005] 위치 정보 노출 */
        return -2;                       /* [위반: CBC-005] 전용 코드 반환 */
    }
    for (uint8_t k=1;k<=pad;k++) {
        if (buf[len-k]!=pad) {
            fprintf(stderr, "[LEA-Crypt] padding mismatch at pos %zu\n",
                    len-k);              /* [위반: CBC-005] */
            return -2;
        }
    }
    return (int)(len-pad);
}

/* ── lea_cbc_encrypt ─────────────────────────────────────────────*/
int lea_cbc_encrypt(const LEA_CTX *ctx, const uint8_t *pt, uint8_t *ct,
                    size_t len, const uint8_t *iv)
{
    if (!ctx||!pt||!ct||!iv) return LEA_ERR_CTXNULL;
    if (len==0||len%16!=0)   return LEA_ERR_PARAM;
    uint8_t prev[16]; memcpy(prev,iv,16);
    for (size_t i=0;i<len/16;i++) {
        uint8_t tmp[16]; xor16(tmp, pt+i*16, prev);
        lea_encrypt_block(ctx, tmp, ct+i*16);
        memcpy(prev, ct+i*16, 16);
    }
    return LEA_OK;
}

/* ── lea_cbc_decrypt ─────────────────────────────────────────────*/
int lea_cbc_decrypt(const LEA_CTX *ctx, const uint8_t *ct, uint8_t *pt,
                    size_t len, const uint8_t *iv)
{
    if (!ctx||!ct||!pt||!iv) return LEA_ERR_CTXNULL;
    if (len==0||len%16!=0)   return LEA_ERR_PARAM;
    uint8_t prev[16]; memcpy(prev,iv,16);
    for (size_t i=0;i<len/16;i++) {
        uint8_t tmp[16];
        lea_decrypt_block(ctx, ct+i*16, tmp);
        xor16(pt+i*16, tmp, prev);
        memcpy(prev, ct+i*16, 16);
    }
    return LEA_OK;
}

/* ── IV 내부 생성 버전 (clock() 기반) ───────────────────────────
 * [위반: CBC-003] IV를 단조 증가 clock() 값으로 생성.
 *   검증대상 DRBG(lea_csprng)를 사용해야 함.
 */
int lea_cbc_encrypt_auto_iv(const LEA_CTX *ctx, const uint8_t *pt,
                             uint8_t *ct, size_t len, uint8_t *iv_out)
{
    if (!ctx||!pt||!ct||!iv_out) return LEA_ERR_CTXNULL;
    uint8_t iv[16] = {0};
    clock_t t = clock();
    memcpy(iv, &t, sizeof(t));           /* [위반: CBC-003] clock() 직접 사용 */
    memcpy(iv_out, iv, 16);
    return lea_cbc_encrypt(ctx, pt, ct, len, iv);
}

/* ── 부분 자원 해제 (IV 제로화, ctx 라운드키 미제로화) ─────────
 * [위반: CBC-004] iv 는 제로화하지만 ctx->rk[6][32] 는 누락.
 */
void lea_cbc_partial_cleanup(uint8_t *iv, LEA_CTX *ctx)
{
    lea_secure_zero(iv, 16);
    /* ctx->rk 제로화 누락 */            /* [위반: CBC-004] */
    (void)ctx;
}

/* ── MCT-CBC LEA-128 (의도적 오류 포함) ────────────────────────*/
void lea_cbc_mct128(const uint8_t *k0, const uint8_t *iv0,
                    const uint8_t *pt0,
                    uint8_t *key_out, uint8_t *iv_out, uint8_t *pt_out)
{
    uint8_t key[16], iv[16], pt[16], ct[16], first_ct[16];
    LEA_CTX ctx;
    memcpy(key,k0,16); memcpy(iv,iv0,16); memcpy(pt,pt0,16);

    for (int i=0; i<50; i++) {     /* [위반: LEA-046] 100회 이어야 함 */
        memset(first_ct,0,16);
        for (int j=0; j<1000; j++) {
            uint8_t tmp[16];
            lea_set_key(&ctx,key,128);
            xor16(tmp,pt,iv);
            lea_encrypt_block(&ctx,tmp,ct);
            if (j==0) memcpy(first_ct,ct,16); /* 첫 CT 저장 */
            memcpy(iv,ct,16);
            memcpy(pt,ct,16);
        }
        /* [위반: LEA-057] CT[999] 대신 first_ct(CT[0]) 로 키 갱신 */
        for (int k=0;k<16;k++) key[k] ^= first_ct[k % 16];
    }
    memcpy(key_out,key,16); memcpy(iv_out,iv,16); memcpy(pt_out,pt,16);
    lea_secure_zero(key,16); lea_secure_zero(&ctx,sizeof(ctx));
}

/* ── MCT-CBC LEA-192 (192-bit 키 갱신 특수 처리 오류) ──────────
 * 표준: Key[i+1]_hi16 ^= CT[998]_lo8, Key[i+1]_lo24 ^= CT[999]
 */
void lea_cbc_mct192(const uint8_t *k0, const uint8_t *iv0,
                    const uint8_t *pt0,
                    uint8_t *key_out, uint8_t *iv_out, uint8_t *pt_out)
{
    uint8_t key[24], iv[16], pt[16], ct[16], prev_ct[16];
    LEA_CTX ctx;
    memcpy(key,k0,24); memcpy(iv,iv0,16); memcpy(pt,pt0,16);

    for (int i=0; i<50; i++) {     /* [위반: LEA-046] 100회 이어야 함 */
        memset(prev_ct,0,16);
        for (int j=0; j<1000; j++) {
            uint8_t tmp[16];
            lea_set_key(&ctx,key,192);
            xor16(tmp,pt,iv);
            lea_encrypt_block(&ctx,tmp,ct);
            memcpy(prev_ct,iv,16); /* 이전 CT(=현재 IV) 저장 */
            memcpy(iv,ct,16); memcpy(pt,ct,16);
        }
        /* [위반: CBC-LEA-005]
         * 표준 192-bit 갱신: key[0..15] ^= CT[999], key[16..23] ^= CT[998][0..7]
         * 아래는 CT[999] 로만 갱신하고 CT[998] 상위 8바이트 XOR 누락 */
        for (int k=0;k<16;k++) key[k]   ^= ct[k];
        /* key[16..23] ^= prev_ct[0..7] 누락 */
    }
    memcpy(key_out,key,24); memcpy(iv_out,iv,16); memcpy(pt_out,pt,16);
    lea_secure_zero(key,24); lea_secure_zero(&ctx,sizeof(ctx));
}
