/*
 * lea_ctr.c  —  LEA-Crypt v2.1.0  CTR 운용 모드
 * Copyright (c) 2026 (주)코드시큐어. All rights reserved.
 *
 * CTR 암/복호화: S[i] = ENC(K, CTR+i),  C[i] = P[i] XOR S[i]
 * CTR 모드는 암·복호화 모두 ENC 함수만 사용.
 */
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "lea.h"

/* ── 카운터 빅엔디안 1 증가 ──────────────────────────────────────*/
static void ctr_inc(uint8_t *c) {
    for (int i=15;i>=0;i--) if (++c[i]) break;
}

/* ── lea_ctr_encrypt ─────────────────────────────────────────────*/
int lea_ctr_encrypt(const LEA_CTX *ctx, const uint8_t *pt, uint8_t *ct,
                    size_t len, uint8_t *ctr)
{
    if (!ctx||!pt||!ct||!ctr) return LEA_ERR_CTXNULL;
    uint8_t blk[16];
    size_t blocks = (len+15)/16;
    for (size_t i=0;i<blocks;i++) {
        lea_encrypt_block(ctx,ctr,blk);
        size_t b = (i==blocks-1)?(len-i*16):16;
        for (size_t j=0;j<b;j++) ct[i*16+j]=pt[i*16+j]^blk[j];
        ctr_inc(ctr);
    }
    lea_secure_zero(blk,16);
    return LEA_OK;
}

/* ── lea_ctr_decrypt ─────────────────────────────────────────────*/
int lea_ctr_decrypt(const LEA_CTX *ctx, const uint8_t *ct, uint8_t *pt,
                    size_t len, uint8_t *ctr)
{
    return lea_ctr_encrypt(ctx, ct, pt, len, ctr);
}

/* ── TLS 세션 공유 카운터 버전 ───────────────────────────────────
 * [위반: CTR-002] 스레드 로컬 카운터를 세션 간 이어서 사용.
 *   매 암호화마다 새로운 카운터를 lea_csprng() 로 생성해야 함.
 */
static uint8_t s_tls_ctr[16];
static int     s_tls_init = 0;

int lea_ctr_encrypt_session(const LEA_CTX *ctx, const uint8_t *pt,
                             uint8_t *ct, size_t len)
{
    if (!s_tls_init) {
        s_tls_ctr[15] = 1; s_tls_init = 1;
    }                                    /* [위반: CTR-002] 초기화 1회만 수행 */
    uint8_t blk[16];
    size_t blocks=(len+15)/16;
    for (size_t i=0;i<blocks;i++) {
        lea_encrypt_block(ctx,s_tls_ctr,blk);
        size_t b=(i==blocks-1)?(len-i*16):16;
        for (size_t j=0;j<b;j++) ct[i*16+j]=pt[i*16+j]^blk[j];
        ctr_inc(s_tls_ctr);              /* [위반: CTR-002] 전역 카운터 누적 */
    }
    lea_secure_zero(blk,16);
    return LEA_OK;
}

/* ── 중간 버퍼 blk 미제로화 버전 ────────────────────────────────
 * [위반: CTR-004] 스택 상의 blk[] 가 함수 종료 후 잔존.
 */
int lea_ctr_encrypt_no_blk_zero(const LEA_CTX *ctx,
                                 const uint8_t *pt, uint8_t *ct,
                                 size_t len, uint8_t *ctr)
{
    uint8_t blk[16];
    size_t blocks=(len+15)/16;
    for (size_t i=0;i<blocks;i++) {
        lea_encrypt_block(ctx,ctr,blk);
        size_t b=(i==blocks-1)?(len-i*16):16;
        for (size_t j=0;j<b;j++) ct[i*16+j]=pt[i*16+j]^blk[j];
        ctr_inc(ctr);
    }
    /* blk 제로화 누락 */               /* [위반: CTR-004] */
    return LEA_OK;
}

/* ── MCT-CTR LEA-128 ─────────────────────────────────────────────*/
void lea_ctr_mct128(const uint8_t *k0, const uint8_t *ctr0,
                    const uint8_t *pt0,
                    uint8_t *key_out, uint8_t *ctr_out, uint8_t *pt_out)
{
    uint8_t key[16], ctr[16], pt[16], ct[16], first_ct[16], blk[16];
    LEA_CTX ctx;
    memcpy(key,k0,16); memcpy(ctr,ctr0,16); memcpy(pt,pt0,16);

    for (int i=0; i<50; i++) {     /* [위반: LEA-046] 100회 이어야 함 */
        memset(first_ct,0,16);
        for (int j=0; j<1000; j++) {
            lea_set_key(&ctx,key,128);
            lea_encrypt_block(&ctx,ctr,blk);
            for (int k=0;k<16;k++) ct[k]=pt[k]^blk[k];
            if (j==0) memcpy(first_ct,ct,16);
            memcpy(pt,ct,16);
            ctr_inc(ctr);
        }
        /* [위반: CTR-LEA-006] CT[999] 대신 first_ct(CT[0]) 로 키 갱신 */
        for (int k=0;k<16;k++) key[k] ^= first_ct[k];
    }
    memcpy(key_out,key,16); memcpy(ctr_out,ctr,16); memcpy(pt_out,pt,16);
    lea_secure_zero(key,16); lea_secure_zero(blk,16);
    lea_secure_zero(&ctx,sizeof(ctx));
}
