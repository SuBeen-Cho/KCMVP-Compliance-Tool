# libclang Before/After 검증용 테스트 코드

이 ZIP은 libclang 심볼 그래프 개선점을 검증하기 위한 최소한의 LEA 구현체입니다.

## 파일별 테스트 목적

| 파일 | 관련 규칙 | 기대 결과 |
|------|-----------|-----------|
| src/lea_key_correct.c | LEA-010 | 표준 delta → 위반 없음 |
| src/lea_key_wrong.c   | LEA-010 | 비표준 delta → 위반 탐지 (AFTER만) |
| src/lea_encrypt.c     | LEA-031 | 포인터 FP → AFTER에서 제거 |
| src/lea_decrypt_bad.c | LEA-034 | 뺄셈 없음 → 위반, 메시지에 실제 타입명 |
| src/lea_clear.c       | COM-001 | memset 제로화 → 정상 탐지 |
| src/lea_cbc.c         | CBC-001 | IV 재사용 → 위반 탐지 |
| include/lea_types.h   | (공통)  | typedef 명시 → type_aliases 수집 검증 |

## Before vs After 핵심 차이

1. **LEA-010**: BEFORE=0 violations (FN), AFTER=1 violation (array_inits 활용)
2. **LEA-031**: BEFORE=포인터 타입 불명, AFTER=FP 제거 (type_aliases 활용)
3. **LEA-034**: BEFORE="pt:uint32_t", AFTER="pt:unsigned int" (typedef 해소)
