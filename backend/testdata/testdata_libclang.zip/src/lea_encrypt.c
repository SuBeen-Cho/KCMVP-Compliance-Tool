#include "lea_types.h"

/*
 * 포인터 기반 바이트 연산 — LEA-031 FP 검증용
 *
 * unsigned char* 타입의 포인터 연산에서 XOR+ADD 패턴이 나타나지만
 * 이것은 정수 LEA 연산이 아닌 바이트 레벨 포인터 연산이다.
 * AFTER: type_aliases로 포인터 타입 식별 → FP 자동 제거
 * BEFORE: 포인터 타입 정보 없음 → FP 발생 가능
 */
void lea_xor_block_ptr(uint8_t *dst, const uint8_t *src, const uint8_t *key,
                       int len) {
    int i;
    for (i = 0; i < len; i++) {
        /* 포인터 바이트 연산: dst = src XOR (key + offset) */
        dst[i] = src[i] ^ (key[i] + (uint8_t)i);
    }
}

/*
 * 올바른 LEA 암호화 — XOR→ADD 순서 정확
 */
void lea_encrypt(uint32_t *ct, const uint32_t *pt,
                 const uint32_t RK[32][6]) {
    uint32_t x0 = pt[0], x1 = pt[1], x2 = pt[2], x3 = pt[3];
    int i;

    for (i = 0; i < 32; i++) {
        uint32_t t0, t1, t2, t3;
        /* 올바른 순서: XOR 먼저, 그 다음 ADD */
        t0 = ((x0 ^ RK[i][0]) + (x1 ^ RK[i][1])) ;
        t1 = ((x1 ^ RK[i][2]) + (x2 ^ RK[i][3])) ;
        t2 = ((x2 ^ RK[i][4]) + (x3 ^ RK[i][5])) ;
        t3 = x0;
        x0 = t0; x1 = t1; x2 = t2; x3 = t3;
    }

    ct[0] = x0; ct[1] = x1; ct[2] = x2; ct[3] = x3;
}
