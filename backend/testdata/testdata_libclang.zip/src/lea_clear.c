#include "lea_types.h"
#include <string.h>

/*
 * 올바른 키 제로화 — COM-001 정상 케이스
 *
 * memset()으로 라운드키 배열을 0으로 초기화.
 * libclang: memset을 정확한 심볼로 탐지
 * pycparser 환경(fake_libc): __builtin___memset_chk 확장 → 수정된 버그로 탐지됨
 */
void lea_clear_key(uint32_t RK[32][6]) {
    memset(RK, 0, sizeof(uint32_t) * 32 * 6);
}

void lea_secure_cleanup(uint32_t *RK, uint8_t *key_buf, int key_len) {
    /* 라운드키 제로화 */
    memset(RK, 0, sizeof(uint32_t) * 32 * 6);
    /* 원본 키 버퍼 제로화 */
    memset(key_buf, 0, (size_t)key_len);
}
