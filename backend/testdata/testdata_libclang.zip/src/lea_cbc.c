#include "lea_types.h"
#include <string.h>

/*
 * CBC 모드 암호화 — IV 재사용 위반 케이스
 *
 * CBC-001: IV는 매 암호화마다 새로 생성해야 하지만
 * 이 구현에서는 고정 IV를 전역변수로 재사용함.
 */

/* 위반: 고정 IV — 매 암호화마다 동일한 값 사용 */
static const uint8_t fixed_iv[16] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f
};

static void xor_block(uint8_t *dst, const uint8_t *a, const uint8_t *b) {
    int i;
    for (i = 0; i < 16; i++) dst[i] = a[i] ^ b[i];
}

extern void lea_encrypt(uint32_t *ct, const uint32_t *pt,
                        const uint32_t RK[32][6]);

/*
 * CBC 암호화 — IV 재사용 문제 있음
 * 올바른 구현: iv 파라미터를 매번 새로운 난수로 받아야 함
 */
void lea_cbc_enc(uint8_t *ct, const uint8_t *pt, int pt_len,
                 const uint32_t RK[32][6]) {
    uint8_t prev[16];
    int i;

    /* fixed_iv 재사용 — CBC-001 위반 */
    memcpy(prev, fixed_iv, 16);

    for (i = 0; i < pt_len; i += 16) {
        uint8_t block[16];
        xor_block(block, pt + i, prev);
        lea_encrypt((uint32_t *)ct + i/4,
                    (const uint32_t *)block, RK);
        memcpy(prev, ct + i, 16);
    }
}

/*
 * CBC 복호화 — 동일하게 fixed_iv 재사용
 */
void lea_cbc_dec(uint8_t *pt, const uint8_t *ct, int ct_len,
                 const uint32_t RK[32][6]) {
    uint8_t prev[16];
    int i;

    /* fixed_iv 재사용 — CBC-001 위반 */
    memcpy(prev, fixed_iv, 16);

    for (i = 0; i < ct_len; i += 16) {
        uint8_t block[16];
        lea_encrypt((uint32_t *)block,
                    (const uint32_t *)(ct + i), RK);
        xor_block(pt + i, block, prev);
        memcpy(prev, ct + i, 16);
    }
}
