#include "lea_types.h"
#include <string.h>

/* KS X 3246 표준 delta 상수 (128비트 키용) */
static const uint32_t delta_128[4] = {
    0xc3efe9db, 0x44626b02, 0x79e27c8a, 0x78df30ec
};

/* 256비트 키용 delta 상수 */
static const uint32_t delta_256[8] = {
    0xc3efe9db, 0x44626b02, 0x79e27c8a, 0x78df30ec,
    0x715ea49e, 0xc785da0a, 0xe04ef22a, 0xe5c40957
};

static uint32_t ROL32(uint32_t x, int n) {
    return (x << n) | (x >> (32 - n));
}

/* 표준 키 스케줄: ARX 구조 + 표준 delta 사용 */
void lea_set_key(uint32_t RK[32][6], const uint8_t *mk, int mk_len) {
    uint32_t T[4];
    int i;

    T[0] = ((uint32_t)mk[0]  << 24) | ((uint32_t)mk[1]  << 16)
         | ((uint32_t)mk[2]  <<  8) |  (uint32_t)mk[3];
    T[1] = ((uint32_t)mk[4]  << 24) | ((uint32_t)mk[5]  << 16)
         | ((uint32_t)mk[6]  <<  8) |  (uint32_t)mk[7];
    T[2] = ((uint32_t)mk[8]  << 24) | ((uint32_t)mk[9]  << 16)
         | ((uint32_t)mk[10] <<  8) |  (uint32_t)mk[11];
    T[3] = ((uint32_t)mk[12] << 24) | ((uint32_t)mk[13] << 16)
         | ((uint32_t)mk[14] <<  8) |  (uint32_t)mk[15];

    for (i = 0; i < 32; i++) {
        T[0] = ROL32(T[0] + ROL32(delta_128[i % 4], i), 1);
        T[1] = ROL32(T[1] + ROL32(delta_128[(i+1) % 4], i), 3);
        T[2] = ROL32(T[2] + ROL32(delta_128[(i+2) % 4], i), 6);
        T[3] = ROL32(T[3] + ROL32(delta_128[(i+3) % 4], i), 11);

        RK[i][0] = T[0];
        RK[i][1] = T[1];
        RK[i][2] = T[2];
        RK[i][3] = T[1];
        RK[i][4] = T[3];
        RK[i][5] = T[1];
    }
}
