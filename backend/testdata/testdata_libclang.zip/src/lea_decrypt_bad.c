#include "lea_types.h"

/*
 * 의도적으로 잘못된 복호화 — LEA-034 위반 검증용
 *
 * 올바른 LEA 역연산에는 모듈러 뺄셈(-)이 있어야 하지만
 * 이 구현에서는 뺄셈 대신 덧셈을 사용하고 있음.
 *
 * BEFORE 메시지: "파라미터 타입: pt:uint32_t, ct:uint32_t"
 * AFTER  메시지: "파라미터 타입: pt:unsigned int, ct:unsigned int"
 *                (type_aliases로 typedef 해소됨)
 */
void lea_decrypt(uint32_t *pt, const uint32_t *ct,
                 const uint32_t RK[32][6]) {
    uint32_t x0 = ct[0], x1 = ct[1], x2 = ct[2], x3 = ct[3];
    int i;

    for (i = 31; i >= 0; i--) {
        uint32_t t0, t1, t2, t3;
        /*
         * 잘못된 역연산: 뺄셈(-) 없이 XOR만 사용
         * 올바른 구현은: t = (x ^ RK) - y 형태여야 함
         */
        t3 = x0;
        t0 = (x0 ^ RK[i][1]) + x1;   /* 뺄셈 없음 — 오류 */
        t1 = (x1 ^ RK[i][3]) + x2;   /* 뺄셈 없음 — 오류 */
        t2 = (x2 ^ RK[i][5]) + x3;   /* 뺄셈 없음 — 오류 */
        x0 = t0; x1 = t1; x2 = t2; x3 = t3;
    }

    pt[0] = x0; pt[1] = x1; pt[2] = x2; pt[3] = x3;
}
