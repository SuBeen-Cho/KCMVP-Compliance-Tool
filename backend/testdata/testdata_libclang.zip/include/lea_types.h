#ifndef LEA_TYPES_H
#define LEA_TYPES_H

/*
 * LEA 암호모듈 타입 정의
 *
 * typedef 선언 — libclang의 type_aliases 수집 검증용:
 *   uint32_t → unsigned int
 *   uint8_t  → unsigned char
 *   uint64_t → unsigned long long
 *
 * Before(pycparser): type_aliases = {} (빈 딕셔너리)
 * After (libclang):  type_aliases = {
 *                      "uint32_t": "unsigned int",
 *                      "uint8_t":  "unsigned char",
 *                      "uint64_t": "unsigned long long"
 *                    }
 */

typedef unsigned int       uint32_t;
typedef unsigned char      uint8_t;
typedef unsigned short     uint16_t;
typedef unsigned long long uint64_t;

/* LEA 블록/키 크기 상수 */
#define LEA_BLOCK_SIZE  16   /* 바이트 */
#define LEA_KEY_128     16
#define LEA_KEY_192     24
#define LEA_KEY_256     32
#define LEA_ROUNDS      32

#endif /* LEA_TYPES_H */
