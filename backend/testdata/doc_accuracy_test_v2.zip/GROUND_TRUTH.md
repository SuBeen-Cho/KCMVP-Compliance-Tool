# DOC 정확도 테스트 v2 Ground Truth
# 형식: 파일명(zip 내 경로) | P/N | 위반규칙(P인 경우) | 설명
#
# P = 위반 있음, N = 위반 없음 (파일 레벨 판정)
#
design/design_pass.pdf | N | - | 55개 DOC 규칙 모두 충족 (실제 설계서 수준)
design/design_fail.pdf | P | DOC-001,DOC-004,DOC-007,DOC-009,DOC-010,DOC-017,DOC-022 | 핵심 규칙 7개 의도적 누락
config_mgmt/config_pass.pdf | N | - | 4개 CM 규칙 모두 충족
test/test_pass.pdf | N | - | 5개 TEST 규칙 모두 충족
