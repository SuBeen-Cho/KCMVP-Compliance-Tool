#include <stdint.h>
unsigned int gcm_tag_len = 3;   /* 4~16 밖 → GCM-002 */
