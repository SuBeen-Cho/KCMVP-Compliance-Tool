#include <stdint.h>
/* lea_cmac_* 심볼 없음 → CMAC-LEA-001 위반 기대 */
