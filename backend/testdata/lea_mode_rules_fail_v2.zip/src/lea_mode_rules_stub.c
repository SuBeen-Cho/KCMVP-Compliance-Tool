#include "lea_locl.h"
#include <stdint.h>
#include <string.h>

// ================
// [공통] COM-001 통과를 위한 제거 함수 호출(= memset_s)
// ================
void clear_secret(void) {
    unsigned char secret[32];
    // AST file_calls에 memset_s가 들어가게 하기 위함
    memset_s(secret, 0, sizeof(secret));
}

// ================
// [LEA] missing 규칙 통과용 최소 토큰/구조
// ================
// LEA-001: block_size/len/length = 128
int block_len = 128;

// LEA-002: mk_len/key_len/keyLen = 16/24/32
unsigned int mk_len = 16;

// LEA-007: K[16|24|32]
unsigned char K[16];

// LEA-008: X[4]
uint32_t X[4];

// LEA-009: rk/RK[6]
uint32_t rk[6];

// LEA-004: uint32_t ... (rk|round_key|X|T|state|block|delta) 컨텍스트
uint32_t T[6];
uint32_t state[4];
uint32_t delta_arr[1] = {0xc3efe9db}; // LEA-011 매칭용 상수 1개만 포함(오탐 방지)

// LEA-012: 766995 문자열 존재
// 766995

// LEA-013: T = K 또는 memcpy(T, K
void lea_key_schedule_stub(unsigned char *mk) {
    (void)mk;
    // pattern: memcpy(T, K
    memcpy(T, K, sizeof(K));
}

// LEA 회전/워드 연산 패턴 토큰들(문법을 해치지 않기 위해 주석으로만 제공)
/*
  ROL1 ROL3 ROL6 ROL9 ROL11 ROL13 ROL17
  ROR5 ROR3 ROR9
  X = P; X = C; C = X; P = X_Nr;
*/

// LEA-051: lea_set_key 토큰
    // LEA-052 missing 패턴은 `.*`가 DOTALL 없이 동작하므로
    // `typedef/struct`와 `LEA_KEY` 사이가 같은 줄이어야 매칭이 됩니다.
    typedef struct { uint32_t rk[6]; unsigned int round; } LEA_KEY;

int lea_set_key(LEA_KEY *key, const unsigned char *mk, unsigned int mk_len) {
    (void)key;
    (void)mk;
    // LEA-053: return -N (음수 반환)
    return -1;
}

// LEA-055: SIMD 심볼 토큰
// lea_t_sse2

// LEA-048/LEA-058: KAT/MMT/MCT 파일명 패턴 존재
/*
LEA128ECBKAT.req
LEA128ECBKAT.rsp
LEA128CBCKAT.req
LEA128CBCKAT.rsp
LEA128CTRKAT.req
LEA128CTRKAT.rsp
LEA128OFBKAT.req
LEA128OFBKAT.rsp
LEA128CFBKAT.req
LEA128CFBKAT.rsp
LEA128ECBMMT.req
LEA128ECBMMT.rsp
LEA128ECBMCT.req
LEA128ECBMCT.rsp
*/

// ================
// [모드] 우리의 목적: L1 엔진의 regex/missing을 잡기 위한 문자열/값 삽입
// ================

// CCM-002: Nonce 길이(7~13 이외 위반)
unsigned int n_len = 6;

// CCM-003: Tag 길이(허용 집합 이외 위반)
unsigned int tag_len = 5;

// GCM-002: tag 길이 invalid (규칙 패턴이 invalid 길이만 매칭하도록 작성됨)
unsigned int t_len = 3;

// OFB-001: iv 길이(16 이외 위반)
unsigned char iv[15];

// ----------------
// [모드 API missing 규칙] pass/fail에 따라 "토큰" 포함/제외
// ----------------







// ----------------
// [온라인 API missing 규칙] pass/fail에 따라 포함/제외(COM-006)
// ----------------


