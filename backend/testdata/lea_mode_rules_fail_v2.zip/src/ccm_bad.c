#include <stdint.h>
unsigned int ccm_nonce_len = 6;   /* 7~13 범위 밖 → CCM-002 */
unsigned int ccm_tag_len = 5;     /* {4,6,8,10,12,14,16} 밖 → CCM-003 */
