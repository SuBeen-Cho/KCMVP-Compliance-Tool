#include <stdint.h>
unsigned char ofb_iv[15]; /* 16 이 아님 → OFB-001 */
