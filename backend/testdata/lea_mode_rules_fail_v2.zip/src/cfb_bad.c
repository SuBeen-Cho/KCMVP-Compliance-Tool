#include <stdint.h>
/* intentionally no lea_cfb128_enc/dec → CFB-LEA-001 위반 */
