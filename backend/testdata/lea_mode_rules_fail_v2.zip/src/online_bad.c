#include <stdint.h>
/* lea_online_* 심볼 없음 → COM-006 위반 기대 */
