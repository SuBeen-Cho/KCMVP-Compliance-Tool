#ifndef LEA_LOCL_H
#define LEA_LOCL_H
/* empty - tests only */
#endif
