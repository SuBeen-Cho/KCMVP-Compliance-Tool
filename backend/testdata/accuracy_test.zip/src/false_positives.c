
#include <stdint.h>
#include <string.h>
#include "lea.h"

/* [F1] COM-003 오탐 후보: LEA 델타 상수 — 공개 알고리즘 상수 */
static const uint32_t lea_delta[8] = {
    0xc3efe9db, 0x44626b02, 0x79e27c8a, 0x78df30ec,
    0x715ea49e, 0xc785da0a, 0xe04ef22a, 0xe5c40957
};

/* [F2] COM-003 오탐 후보: S-box 치환표 — 알고리즘 상수 */
static const uint8_t aria_sbox[16] = {
    0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5,
    0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76
};

/* [F3] COM-003 오탐 후보: KAT 테스트 벡터 */
static const uint8_t kat_plaintext[16] = {
    0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
    0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f
};
static const uint8_t kat_expected_ct[16] = {
    0x9a, 0x4b, 0x0e, 0xf4, 0x23, 0x1e, 0x77, 0x5b,
    0xdc, 0xa8, 0x67, 0x21, 0x30, 0x9f, 0xe5, 0x12
};

/* [F4] COM-004 오탐 후보: rand()를 테스트 인덱스(비암호 용도)에 사용 */
void false_pos_rand_for_test(void) {
    srand(42);
    int test_case_idx = rand() % 100;   /* 테스트 케이스 선택용, 암호 연산 무관 */
    (void)test_case_idx;
}

/* [F5] COM-001 오탐 후보: memset_s로 올바르게 제로화 */
void false_pos_correct_zeroize(uint8_t *key_buf, size_t len) {
    memset_s(key_buf, len, 0, len);   /* 올바른 보안 제로화 */
}

/* [F6] CBC-003 오탐 후보: IV를 CSPRNG로 생성 후 전달 */
void false_pos_random_iv(LEA_KEY *ctx, uint8_t *pt, size_t len, uint8_t *ct) {
    uint8_t iv[16];
    lea_generate_random(iv, 16);   /* CSPRNG로 IV 생성 */
    lea_cbc_encrypt(ctx, pt, ct, len, iv);
}
