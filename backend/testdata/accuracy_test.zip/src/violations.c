
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "lea.h"

/* [V1] COM-003: 하드코딩 키 — 변수명 key, lea_set_key에 직접 전달 */
void real_violation_hardcoded_key(LEA_KEY *ctx) {
    uint8_t master_key[16] = {
        0x0f, 0x1e, 0x2d, 0x3c, 0x4b, 0x5a, 0x69, 0x78,
        0x87, 0x96, 0xa5, 0xb4, 0xc3, 0xd2, 0xe1, 0xf0
    };
    lea_set_key(ctx, master_key, 128);
}

/* [V2] COM-001: 키 버퍼를 일반 memset으로 제로화 (컴파일러 최적화 취약) */
void real_violation_weak_zeroize(LEA_KEY *ctx, uint8_t *key_buf, size_t len) {
    lea_set_key(ctx, key_buf, 128);
    memset(key_buf, 0, len);   /* 위반: memset_s 또는 explicit_bzero 사용해야 함 */
}

/* [V3] COM-004: rand()로 IV 생성 — 암호학적 안전성 없음 */
void real_violation_weak_rng(uint8_t *iv) {
    srand((unsigned int)time(NULL));
    for (int i = 0; i < 16; i++) {
        iv[i] = (uint8_t)(rand() & 0xff);
    }
}

/* [V4] CBC-003: IV가 하드코딩(상수 0으로 고정) */
void real_violation_fixed_iv(LEA_KEY *ctx, uint8_t *plaintext, size_t len, uint8_t *out) {
    uint8_t iv[16] = {0x00, 0x00, 0x00, 0x00,
                      0x00, 0x00, 0x00, 0x00,
                      0x00, 0x00, 0x00, 0x00,
                      0x00, 0x00, 0x00, 0x00};
    lea_cbc_encrypt(ctx, plaintext, out, len, iv);
}

/* [V5] COM-005: init 없이 update 직접 호출 */
void real_violation_api_order(LEA_CTX *ctx, uint8_t *data, size_t len) {
    lea_online_update(ctx, data, len);   /* 위반: lea_online_init 먼저 호출해야 함 */
    lea_online_final(ctx, data, &len);
}

/* [V6] COM-003: secret_iv 변수명 + 암호 함수 인자로 전달 */
void real_violation_hardcoded_iv(LEA_KEY *ctx, uint8_t *pt, size_t len, uint8_t *ct) {
    uint8_t secret_iv[16] = {
        0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x00, 0x11,
        0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99
    };
    lea_cbc_encrypt(ctx, pt, ct, len, secret_iv);
}
