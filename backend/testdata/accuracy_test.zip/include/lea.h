
#pragma once
#include <stdint.h>
#include <stddef.h>
typedef struct { uint32_t rk[192]; int keylen; } LEA_KEY;
typedef struct { LEA_KEY key; uint8_t buf[16]; size_t blen; } LEA_CTX;
int  lea_set_key(LEA_KEY *ctx, const uint8_t *key, int keylen);
int  lea_cbc_encrypt(LEA_KEY *ctx, const uint8_t *in, uint8_t *out, size_t len, uint8_t *iv);
int  lea_cbc_decrypt(LEA_KEY *ctx, const uint8_t *in, uint8_t *out, size_t len, uint8_t *iv);
int  lea_online_init(LEA_CTX *ctx, const uint8_t *key, int keylen, const uint8_t *iv);
int  lea_online_update(LEA_CTX *ctx, const uint8_t *in, size_t len);
int  lea_online_final(LEA_CTX *ctx, uint8_t *out, size_t *outlen);
void lea_generate_random(uint8_t *buf, size_t len);
