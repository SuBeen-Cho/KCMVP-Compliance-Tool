#ifndef _CONFIG_H_
#define _CONFIG_H_

#define IS_LITTLE_ENDIAN 1

#ifdef _WIN32
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

#endif
