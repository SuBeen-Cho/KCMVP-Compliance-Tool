/*
 * LEA Internal Header — 이 파일은 정상 참조용
 * uint32_t 사용 및 ROL/ROR 매크로 정의 확인을 위한 파일
 */

#ifndef _LEA_LOCL_H_
#define _LEA_LOCL_H_

#include "lea.h"

#define ROR(W,i) (((W) >> (i)) | ((W) << (32 - (i))))
#define ROL(W,i) (((W) << (i)) | ((W) >> (32 - (i))))

#define loadU32(v) (v)

void lea_encrypt(unsigned char *ct, const unsigned char *pt, const LEA_KEY *key);
void lea_decrypt(unsigned char *pt, const unsigned char *ct, const LEA_KEY *key);

#endif
