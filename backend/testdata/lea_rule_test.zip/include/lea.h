/*
 * LEA Public Header — 테스트용 변조
 *
 * [의도적 위반 목록]
 *   LEA-051 (missing): lea_set_key → lea_key_setup 으로 변경
 *   LEA-052 (missing): typedef LEA_KEY → LeaKeyCtx 로 변경
 *   LEA-053 (missing): return -N 음수 반환 코드 없음
 *   CBC-LEA-004 (missing): lea_cbc_enc/dec → cbc_encrypt/decrypt
 *   CTR-LEA-004 (missing): lea_ctr_enc/dec → ctr_encrypt/decrypt
 *   LEA-055 (missing): lea_t_(sse2|avx2|xop|neon) 참조 없음
 */

#ifndef _LEA_HEADER_
#define _LEA_HEADER_

/* LEA-052 위반: 원래 'LEA_KEY' 이어야 하지만 다른 이름 사용 */
typedef struct lea_key_ctx_st {
    unsigned int rk[192];
    unsigned int round;
} LeaKeyCtx;

/* 호환성을 위한 매크로는 일부러 넣지 않음 */
#define LEA_KEY LeaKeyCtx

/* LEA-051 위반: 원래 'lea_set_key' 이어야 함 */
void lea_key_setup(LeaKeyCtx *key, const unsigned char *mk, unsigned int mk_len);

void lea_encrypt(unsigned char *ct, const unsigned char *pt, const LeaKeyCtx *key);
void lea_decrypt(unsigned char *pt, const unsigned char *ct, const LeaKeyCtx *key);

/* LEA-051 위반: lea_set_key 심볼이 존재하지 않음 → 여기서 재선언 필요하지만 빠짐 */

/* CBC-LEA-004 위반: 원래 lea_cbc_enc / lea_cbc_dec 이어야 함 */
void cbc_encrypt(unsigned char *ct, const unsigned char *pt, unsigned int pt_len,
                 const unsigned char *iv, const LeaKeyCtx *key);
void cbc_decrypt(unsigned char *pt, const unsigned char *ct, unsigned int ct_len,
                 const unsigned char *iv, const LeaKeyCtx *key);

/* CTR-LEA-004 위반: 원래 lea_ctr_enc / lea_ctr_dec 이어야 함 */
void ctr_encrypt(unsigned char *ct, const unsigned char *pt, unsigned int pt_len,
                 unsigned char *ctr, const LeaKeyCtx *key);
void ctr_decrypt(unsigned char *pt, const unsigned char *ct, unsigned int ct_len,
                 unsigned char *ctr, const LeaKeyCtx *key);

void lea_ecb_enc(unsigned char *ct, const unsigned char *pt, unsigned int pt_len,
                 const LeaKeyCtx *key);
void lea_ecb_dec(unsigned char *pt, const unsigned char *ct, unsigned int ct_len,
                 const LeaKeyCtx *key);

/* LEA-053 위반: API 에러 반환 규약(return -1 등)이 없음
 *   모든 함수가 void 반환 → 에러 상태를 호출자에게 알릴 수 없음 */

/* LEA-055 위반: SIMD 가속 구현 파일 참조 없음
 *   lea_t_sse2, lea_t_avx2, lea_t_neon 등의 심볼이 없음 */

#endif
