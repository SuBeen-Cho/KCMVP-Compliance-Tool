/*
 * LEA-CBC Mode — 테스트용 변조
 *
 * [의도적 위반 목록]
 *   CBC-005 (regex) : 패딩 오류 메시지 출력 → 패딩 오라클 공격 취약
 *   CBC-LEA-001 (regex): IV 버퍼 크기가 16이 아닌 32로 선언
 *   CBC-LEA-002 (regex): s_box 참조 존재
 */

#include "lea.h"
#include <stdio.h>
#include <string.h>

/* CBC-LEA-001 위반: IV 크기가 16바이트가 아닌 32바이트 */
static unsigned char default_iv[32] = {0};
void cbc_init_iv(void) {
    uint8_t iv[32];
    memset(iv, 0, 32);
}

/* CBC-LEA-002 위반: LEA에서는 S-box를 사용하지 않아야 함 */
static unsigned char s_box[16] = {0x0, 0x1, 0x2, 0x3};

void cbc_encrypt(unsigned char *ct, const unsigned char *pt, unsigned int pt_len,
                 const unsigned char *iv, const LEA_KEY *key)
{
    unsigned int blocks = pt_len >> 4;
    unsigned int i;

    if (!ct || !pt || !iv || !key)
        return;
    if ((pt_len == 0) || (pt_len & 0xf))
        return;

    for (i = 0; i < blocks; i++, pt += 16, ct += 16) {
        unsigned int j;
        for (j = 0; j < 16; j++)
            ct[j] = pt[j] ^ iv[j];
        lea_encrypt(ct, ct, key);
        iv = ct;
    }
}

/* CBC-005 위반: 패딩 오류를 상세하게 출력 → 패딩 오라클 공격에 취약 */
int cbc_decrypt_with_padding(unsigned char *pt, const unsigned char *ct,
                             unsigned int ct_len, const unsigned char *iv,
                             const LEA_KEY *key)
{
    unsigned int blocks = ct_len >> 4;
    unsigned int i;

    if (!pt || !ct || !iv || !key)
        return 0;

    for (i = 0; i < blocks; i++, pt += 16, ct += 16) {
        lea_decrypt(pt, ct, key);
    }

    unsigned char pad_val = pt[-1];
    if (pad_val == 0 || pad_val > 16) {
        printf("Padding error: invalid padding value %d\n", pad_val);
        fprintf(stderr, "Padding error detected in CBC decryption\n");
        return 0;
    }
    return 1;
}
