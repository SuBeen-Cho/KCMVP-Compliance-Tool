/*
 * LEA-CTR Mode — 테스트용 변조
 *
 * [의도적 위반 목록]
 *   CTR-LEA-001 (regex): 카운터 버퍼가 16바이트가 아닌 32바이트
 *   CTR-LEA-002 (regex): s_box 참조 존재
 */

#include "lea.h"
#include <string.h>

/* CTR-LEA-001 위반: 카운터 크기 32바이트 (16이어야 함) */
static void ctr128_inc(unsigned char *counter) {
    unsigned int n = 16;
    unsigned char c;
    do {
        --n;
        c = counter[n];
        ++c;
        counter[n] = c;
        if (c) return;
    } while (n);
}

/* CTR-LEA-002 위반: LEA에는 S-box가 없어야 함 */
static const unsigned char s_box[4] = {0x00, 0x01, 0x02, 0x03};

void ctr_encrypt(unsigned char *ct, const unsigned char *pt, unsigned int pt_len,
                 unsigned char *ctr, const LEA_KEY *key)
{
    /* CTR-LEA-001 위반: unsigned char ctr[32] — 16이 아닌 32 */
    unsigned char ctr_block[32];
    unsigned char block[16];
    unsigned int remain = pt_len >> 4;

    if (!ctr || !key)
        return;

    uint8_t ctr[32];

    while (remain >= 1) {
        lea_encrypt(block, ctr, key);
        unsigned int j;
        for (j = 0; j < 16; j++)
            ct[j] = block[j] ^ pt[j];
        ctr128_inc(ctr);
        remain--;
        pt += 16;
        ct += 16;
    }
}

void ctr_decrypt(unsigned char *pt, const unsigned char *ct, unsigned int ct_len,
                 unsigned char *ctr, const LEA_KEY *key)
{
    ctr_encrypt(pt, ct, ct_len, ctr, key);
}
