/*
 * LEA Core — 테스트용 변조 코드
 *
 * [의도적 위반 목록]
 *   LEA-011 (missing): delta 상수값 제거 (0xc3efe9db 등 8개 상수 없음)
 *   LEA-012 (missing): 766995 주석 없음
 *   LEA-013 (missing): T = K 또는 memcpy(T, K 패턴 없음
 *   LEA-027 (missing): ROL9 → ROL8 로 변조
 *   LEA-028 (missing): ROR5 → ROR4 로 변조
 *   LEA-029 (missing): ROR3 → ROR2 로 변조
 *   LEA-041 (regex) : s_box 사용 추가 — LEA는 S-box 없는 ARX 구조
 *   LEA-054 (missing): #include "lea_locl.h" 제거
 *   COM-001 (missing): memset / explicit_bzero 등 잔존 정보 제거 함수 없음
 *   COM-003 (regex) : 하드코딩된 키 배열 추가
 */

#include "lea.h"
#include <string.h>

/* ── LEA-041 위반: S-box 사용 (LEA는 S-box가 없어야 함) ── */
static const unsigned char s_box[256] = {
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,
    0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76
};

/* ── COM-003 위반: 하드코딩된 키 ── */
static const unsigned char HARDCODED_KEY[16] = {
    0x0f, 0x1e, 0x2d, 0x3c, 0x4b, 0x5a, 0x69, 0x78,
    0x87, 0x96, 0xa5, 0xb4, 0xc3, 0xd2, 0xe1, 0xf0
};

/* ── LEA-011 위반: delta 상수가 규격값이 아닌 더미값으로 대체됨 ── */
static const unsigned int delta[8][36] = {
    {0xAAAAAAAA, 0xBBBBBBBB, 0xCCCCCCCC, 0xDDDDDDDD,
     0xEEEEEEEE, 0xFFFFFFFF, 0x11111111, 0x22222222,
     0x33333333, 0x44444444, 0x55555555, 0x66666666,
     0x77777777, 0x88888888, 0x99999999, 0x00000000,
     0xAAAAAAAA, 0xBBBBBBBB, 0xCCCCCCCC, 0xDDDDDDDD,
     0xEEEEEEEE, 0xFFFFFFFF, 0x11111111, 0x22222222,
     0x33333333, 0x44444444, 0x55555555, 0x66666666,
     0x77777777, 0x88888888, 0x99999999, 0x00000000,
     0xAAAAAAAA, 0xBBBBBBBB, 0xCCCCCCCC, 0xDDDDDDDD},
    {0x11111111, 0x22222222, 0x33333333, 0x44444444,
     0x55555555, 0x66666666, 0x77777777, 0x88888888,
     0x99999999, 0xAAAAAAAA, 0xBBBBBBBB, 0xCCCCCCCC,
     0xDDDDDDDD, 0xEEEEEEEE, 0xFFFFFFFF, 0x00000000,
     0x11111111, 0x22222222, 0x33333333, 0x44444444,
     0x55555555, 0x66666666, 0x77777777, 0x88888888,
     0x99999999, 0xAAAAAAAA, 0xBBBBBBBB, 0xCCCCCCCC,
     0xDDDDDDDD, 0xEEEEEEEE, 0xFFFFFFFF, 0x00000000,
     0x11111111, 0x22222222, 0x33333333, 0x44444444},
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
};

#define ROR(W,i) (((W) >> (i)) | ((W) << (32 - (i))))
#define ROL(W,i) (((W) << (i)) | ((W) >> (32 - (i))))

/* ── LEA-013 위반: T = K 초기화 패턴이 없음 (직접 mk를 참조) ── */
void lea_set_key(LEA_KEY *key, const unsigned char *mk, unsigned int mk_len)
{
    if (!key || !mk)
        return;

    const unsigned int *_mk = (const unsigned int *)mk;

    switch (mk_len) {
    case 16:
        key->rk[  0] = ROL(_mk[0] + delta[0][ 0], 1);
        key->rk[  6] = ROL(key->rk[  0] + delta[1][ 1], 1);
        key->rk[ 12] = ROL(key->rk[  6] + delta[2][ 2], 1);

        key->rk[  1] = key->rk[3] = key->rk[5] = ROL(_mk[1] + delta[0][1], 3);
        key->rk[  2] = ROL(_mk[2] + delta[0][2], 6);
        key->rk[  4] = ROL(_mk[3] + delta[0][3], 11);
        break;

    case 24:
        key->rk[  0] = ROL(_mk[0] + delta[0][ 0], 1);
        key->rk[  1] = ROL(_mk[1] + delta[0][ 1], 3);
        key->rk[  2] = ROL(_mk[2] + delta[0][ 2], 6);
        key->rk[  3] = ROL(_mk[3] + delta[0][ 3], 11);
        break;

    case 32:
        key->rk[  0] = ROL(_mk[0] + delta[0][ 0], 1);
        key->rk[  1] = ROL(_mk[1] + delta[0][ 1], 3);
        key->rk[  2] = ROL(_mk[2] + delta[0][ 2], 6);
        key->rk[  3] = ROL(_mk[3] + delta[0][ 3], 11);
        break;

    default:
        return;
    }
    key->round = (mk_len >> 1) + 16;
}

/* ── LEA-027 위반: ROL9→ROL8, LEA-028 위반: ROR5→ROR4, LEA-029 위반: ROR3→ROR2 ── */
void lea_encrypt(unsigned char *ct, const unsigned char *pt, const LEA_KEY *key)
{
    unsigned int X0, X1, X2, X3;
    const unsigned int *_pt = (const unsigned int *)pt;
    unsigned int *_ct = (unsigned int *)ct;

    X0 = _pt[0]; X1 = _pt[1]; X2 = _pt[2]; X3 = _pt[3];

    /* 원래: ROR3, ROR5, ROL9 → 변조: ROR2, ROR4, ROL8 */
    X3 = ROR((X2 ^ key->rk[  4]) + (X3 ^ key->rk[  5]), 2);   /* ROR3→ROR2 */
    X2 = ROR((X1 ^ key->rk[  2]) + (X2 ^ key->rk[  3]), 4);   /* ROR5→ROR4 */
    X1 = ROL((X0 ^ key->rk[  0]) + (X1 ^ key->rk[  1]), 8);   /* ROL9→ROL8 */
    X0 = ROR((X3 ^ key->rk[ 10]) + (X0 ^ key->rk[ 11]), 2);
    X3 = ROR((X2 ^ key->rk[  8]) + (X3 ^ key->rk[  9]), 4);
    X2 = ROL((X1 ^ key->rk[  6]) + (X2 ^ key->rk[  7]), 8);

    _ct[0] = X0; _ct[1] = X1; _ct[2] = X2; _ct[3] = X3;
}

void lea_decrypt(unsigned char *pt, const unsigned char *ct, const LEA_KEY *key)
{
    unsigned int X0, X1, X2, X3;
    unsigned int *_pt = (unsigned int *)pt;
    const unsigned int *_ct = (const unsigned int *)ct;

    X0 = _ct[0]; X1 = _ct[1]; X2 = _ct[2]; X3 = _ct[3];

    /* 복호화도 동일하게 변조 */
    X0 = (ROR(X0, 8) - (X3 ^ key->rk[  6])) ^ key->rk[  7];   /* ROL9→ROL8 기반 역연산 */
    X1 = (ROL(X1, 4) - (X0 ^ key->rk[  8])) ^ key->rk[  9];   /* ROR5→ROR4 기반 역연산 */
    X2 = (ROL(X2, 2) - (X1 ^ key->rk[ 10])) ^ key->rk[ 11];   /* ROR3→ROR2 기반 역연산 */

    _pt[0] = X0; _pt[1] = X1; _pt[2] = X2; _pt[3] = X3;
}

/* ── COM-001 위반: 함수 종료 시 키/상태 메모리를 제거하지 않음 ── */
void lea_run_no_cleanup(const unsigned char *key_bytes)
{
    LEA_KEY key;
    unsigned char pt[16] = {0};
    unsigned char ct[16] = {0};

    lea_set_key(&key, key_bytes, 16);
    lea_encrypt(ct, pt, &key);
    /* memset(&key, 0, sizeof(key)); ← 이 줄이 없으므로 COM-001 위반 */
}
